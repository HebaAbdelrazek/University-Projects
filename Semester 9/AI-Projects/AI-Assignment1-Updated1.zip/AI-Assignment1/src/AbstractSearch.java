import java.util.ArrayList;
import java.util.LinkedList;

public class AbstractSearch {
	
	static Node initialState;
	static ArrayList<Node> solution;
	
	static int heuristic;
	
	static LinkedList<Node> queue;
	static Node currNode;
	
	DepthFirstSearch DF;
	BreadthFirstSearch BF;
	UniformCostSearch UC;
	IterativeDeepeningSearch ID;
	GreedySearch GR;
	AStarSearch AS;
	
	static ArrayList<Node> visited;
	
	boolean done;
	static boolean visualize;
	
	ArrayList<Node> plan;
	
	public AbstractSearch() {
		DF = null;
		BF = null;
		UC = null;
		
		currNode = null;
		
		initialState = null;
		solution = null;
		
		queue = new LinkedList<>();
		
		visited = new ArrayList<>();
		
		plan = new ArrayList<>();
		
		heuristic = -1;
		
	}

	public ArrayList<Node> solve(EndGame problem, String strategy, boolean visualize) { //returns a node containing the path to the destination
		
		this.visualize = visualize;
		
		if(strategy == "DF") {
			DF = new DepthFirstSearch();	
		}
		else if(strategy == "BF") {
			BF = new BreadthFirstSearch();
		}
		else if(strategy == "UC") {
			UC = new UniformCostSearch();
		}
		else if(strategy == "ID") {
			ID = new IterativeDeepeningSearch();
		}
		else if(strategy == "GR1" || strategy == "GR2") {
			GR = new GreedySearch();
		}
		else if(strategy == "AS1" || strategy == "AS2") {
			AS = new AStarSearch();
		}
		
		initialState = new Node(problem.getInitialState()); //make initial state a node
		queue.add(initialState); //add initial state to the queue
		
		visited.add(initialState);
		
		if(strategy == "GR1" || strategy == "AS1") {
			heuristic = 1;
			initialState.setHeuristic(1, problem);
		}
		else if(strategy == "GR2" || strategy == "AS2") {
			heuristic = 2;
			initialState.setHeuristic(2, problem);
		}
		
	//	System.out.print(initialState.getHeuristic());
		
		
		
		
		if(strategy == "DF") {
			solution = DF.depthFirstSearch(queue, problem);					
		}
		else if(strategy == "BF") {
			solution = BF.breadthFirstSearch(queue, problem);
		}
		else if(strategy == "UC") {
			solution = UC.uniformCostSearch(queue, problem);
		}
		else if(strategy == "ID") {
			solution = ID.iterativeDeepeningSearch(queue, problem);
		}
		else if(strategy == "GR1" || strategy == "GR2") {
			solution = GR.greedySearch(queue, problem);
		}
		else if(strategy == "AS1" || strategy == "AS2") {
			solution = AS.aStarSearch(queue, problem);
		}
			
		return solution;
	}
	
	public ArrayList<Node> expand(Node currNode, EndGame problem){
		ArrayList<Node> expandedNodes = new ArrayList<Node>();
		ArrayList<Node> expandedNodesTemp = new ArrayList<Node>();
		
		ArrayList<String> operations = problem.getOperations(currNode.getState()); //get all possible operations for the current node
		
		for(int i = 0 ; i < operations.size() ; i++) { //for each operation, get the next state, create its node, and add it to the expanded nodes
			State nextState = problem.getNextState((State)currNode.getState(), operations.get(i));
			
			Node newNode = new Node(nextState, currNode, operations.get(i), problem.getStepCost(currNode.getState(), operations.get(i), nextState));
			
			boolean visitedFlag = false;
			for(int j = 0 ; j < newNode.getEndGame().visited.size() ; j++)
				if(newNode.getEndGame().nodeVisited(newNode.getEndGame().visited.get(j), newNode))
					visitedFlag = true;
			
			if(!visitedFlag && newNode.getPathCost() < 100) {
				newNode.getEndGame().visited.add(newNode); //add removed node to the visited queue
		
				expandedNodes.add(newNode);
			}
		}
		
//		for(int i = 0; i < expandedNodesTemp.size() ; i++) {
//			if(expandedNodesTemp.get(i).getOperator().equals("snap")) {
//				expandedNodes.add(expandedNodesTemp.get(i));
//				expandedNodesTemp.remove(expandedNodesTemp.get(i));
//			}
//		}
//		for(int i = 0; i < expandedNodesTemp.size() ; i++) {
//			if(expandedNodesTemp.get(i).getOperator().equals("collect")) {
//				expandedNodes.add(expandedNodesTemp.get(i));
//				expandedNodesTemp.remove(expandedNodesTemp.get(i));
//			}
//		}
//		for(int i = 0; i < expandedNodesTemp.size() ; i++) {
//			if(expandedNodesTemp.get(i).getOperator().equals("up") || expandedNodesTemp.get(i).getOperator().equals("down") || expandedNodesTemp.get(i).getOperator().equals("left") || expandedNodesTemp.get(i).getOperator().equals("right")) {
//				expandedNodes.add(expandedNodesTemp.get(i));
//				expandedNodesTemp.remove(expandedNodesTemp.get(i));
//			}
//		}
//		for(int i = 0; i < expandedNodesTemp.size() ; i++) {
//			if(expandedNodesTemp.get(i).getOperator().equals("kill")) {
//				expandedNodes.add(expandedNodesTemp.get(i));
//				expandedNodesTemp.remove(expandedNodesTemp.get(i));
//			}
//		}
//		for(int i = 0; i<expandedNodes.size();i++) {
//		System.out.print(expandedNodes.get(i).get);
		return expandedNodes;
	}
	
}
