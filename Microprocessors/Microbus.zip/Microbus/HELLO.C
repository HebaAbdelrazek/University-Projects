#include<reg51.h> 
#include<stdlib.h>
#include<string.h>
sbit mode = P0^0; //0 training, 1 testing 
sbit user = P0^1; // 0 A, 1 B
sbit LED = P0^3;
sbit LED1 = P0^5;

unsigned long  flightA [9]={0,0,0,0,0,0,0,0,0};
unsigned long  flightB [9]={0,0,0,0,0,0,0,0,0};
unsigned long xdata tmp [9]={0,0,0,0,0,0,0,0,0};
unsigned long xdata test[9]={0,0,0,0,0,0,0,0,0};
unsigned char characters[10] = {'0','0','0','0','0','0','0','0','0','0'};
unsigned int T0_ISR_count = 0;
unsigned char userDone = 0;
//unsigned char userBDone = 0;
int count = 5;
int i =0;

void timer0_isr() interrupt 1 { 
	T0_ISR_count++;
	TF0 = 0; 
	}

	void clearTmpAndCharacters(){
		for(i = 0; i< 9; i++)
			{ 
				tmp[i] = 0;
				characters[i] = '0';
			}
			characters[9] = '0';
	}

	void startTimer(unsigned char prevPosition, unsigned char character, unsigned long* flight){
		if(characters[prevPosition] != '0' && characters[prevPosition+1] == '0'){
		tmp[prevPosition] =  (unsigned long)((TH0 << 8) | TL0 | ((unsigned long)T0_ISR_count << 16));
		TH0 = 0x00;        //Load the timer value 
		TL0 = 0x00;
		T0_ISR_count = 0;	
		characters[prevPosition+1] = character;
			
		if(character == 'l'){
			for(i =0; i<9; i++){
					*(flight + i) += tmp[i];
			}
			clearTmpAndCharacters();
			count--;
		}
		
		}	
		else{
			clearTmpAndCharacters();
		}
	}

	void calcFlight(unsigned long* flight){
		while(count>0){		
					char character = _getkey();
			
					switch(character){
						case '.': 
							TH0 = 0x00;        //Load the timer value 
							TL0 = 0x00;
							T0_ISR_count = 0;
						if(characters[0] == '0')
							characters[0] = '.';
							break;
						case 't':
							startTimer(0, 't', flight);
							break;
						case 'i':
							startTimer(1, 'i', flight);
							break;
							//printf ("The width stroke is: %ld uSec\n", tmp[1]);
						case 'e':
							startTimer(2, 'e', flight);
							break;
						//	printf ("The width stroke is: %ld uSec\n", tmp[2]);
						case '5':
							startTimer(3, '5', flight);
							break;
						//	printf ("The width stroke is: %ld uSec\n", tmp[3]);
						case 'R':
							startTimer(4, 'R', flight);
							break;
						//	printf ("The width stroke is: %ld uSec\n", tmp[4]);
						case 'o':
							startTimer(5, 'o', flight);
							break;
						//	printf ("The width stroke is: %ld uSec\n", tmp[5]);
						case 'n':
							startTimer(6, 'n', flight);
							break;
						//	printf ("The width stroke is: %ld uSec\n", tmp[6]);
						case 'a':
							startTimer(7, 'a', flight);
							break;
							//printf ("The width stroke is: %ld uSec\n", tmp[7]);
						case 'l':
							startTimer(8, 'l', flight);	
//           if(mode){
//						 count = 0;
//					 }						 
							break;	
					}
			}
		
				for(i = 0; i<9 && !mode; i++){
					*(flight + i) = *(flight + i) /5; 
				}
				
			
		}
	
		unsigned char distance(){
			unsigned char userTest = 0;
			unsigned long distA = 0;
			unsigned long distB = 0;
			for(i =0; i< 9; i++){
				distA = distA + ((test[i] - flightA[i])*(test[i] - flightA[i]));
				distB = distB + ((test[i] - flightB[i])*(test[i] - flightB[i]));
			}
			 if(distA > distB){
				 LED = !LED; //if B
			 }
    	else{ //if A
		    LED1 = !LED1;
	     }
		}
	
	
	void main() {
		//mode = 1; //input pin
    //user = 1;	//input pin
		TMOD = 0x10;    //Timer0 mode 1 
		  TR0 = 1;               //turn ON Timer zero 
			ET0 = 1;               //Enable TImer0 Interrupt 
			EA = 1;                 //Enable Global Interrupt  

		 SCON = 0x50;
		   TMOD |= 0x20; //mode 1
			 TH1 = 0xFD; //timer 1 mode 2
			 TR1 = 1;
			 TI = 1;
		while(1) { 
			if(~mode){ //training
				if(~user){ //user A
					if(userDone == 0){
						calcFlight(&flightA);
						userDone = 1;
					}
						
		    }
				else{ //user B
					if(userDone == 1){
						count = 5; //reset count for other user
					  calcFlight(&flightB);
						userDone = 2;
					}
					
		    }
			} 
			else{
				count = 1; //reset count for other user
				calcFlight(&test);
//				if((distance(test, flightA) < distance(test, flightB))){
//					LED = 0;
//				}
				distance();
				for (i=0; i<9;i++){
					test[i] = 0;
				}
			}
		}
	}