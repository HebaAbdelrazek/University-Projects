package networksmedia;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;

public class TheClientHandler implements Runnable
{
 Scanner scn = new Scanner(System.in);
 public String name;
 final DataInputStream dinputs;
 final DataOutputStream doutputs;
 Socket s;
 boolean isloggedin;
  
 
 public static void GetMemberList(){
	 Vector<TheClientHandler> clientslist = Server.clients;
	 System.out.print("Members in this chat are: ");
	 
	 for(int i=0; i< clientslist.size();i++){
		System.out.print(clientslist.get(i).name);
	 }
 }
 
 public TheClientHandler(Socket s, String name,
                         DataInputStream dinputs, DataOutputStream doutputs) {
     this.dinputs = dinputs; this.doutputs = doutputs; this.name = name; this.s = s; this.isloggedin=true;
 }
@Override
 public void run() {

     String receivedmessage;
     while (true) 
     {
         try
         {
             receivedmessage = dinputs.readUTF();  
             System.out.println(receivedmessage);  
             if(receivedmessage.equals("logout")){
                 this.isloggedin=false;
                 this.s.close();
                 break;
             }    
             StringTokenizer st = new StringTokenizer(receivedmessage, "#"); //breaking the message
             String MsgToSend = st.nextToken();
             String recipient = st.nextToken();

             if(MsgToSend.equals("getmemberslist")){
            	 GetMemberList();
             }
             
            for (TheClientHandler mc : Server.clients) 
             {
                 if (mc.name.equals(recipient) && mc.isloggedin==true) 
                 {
                     mc.doutputs.writeUTF(this.name+" : "+MsgToSend);
                     break;
                 }
             }
         } catch (IOException e) {  
             e.printStackTrace();
         }   
     }
     try
     {
         this.dinputs.close();
         this.doutputs.close();
     }catch(IOException e){
         e.printStackTrace();
     }
 }
}