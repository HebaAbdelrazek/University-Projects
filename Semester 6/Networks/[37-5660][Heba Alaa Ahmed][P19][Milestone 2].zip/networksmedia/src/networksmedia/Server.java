package networksmedia;

import java.io.*;
import java.util.*;
import java.net.*;

public class Server 
{
 static Vector<TheClientHandler> clients = new Vector<>();
 static int noOfClients = 0;

 public static void main(String[] args) throws IOException 
 {
     ServerSocket serversocket = new ServerSocket(1233); 
     Socket s;
    while (true) 
     {
         s = serversocket.accept();
         System.out.println("New client request received : " + s);
          
         DataInputStream dinputs = new DataInputStream(s.getInputStream());
         DataOutputStream doutputs = new DataOutputStream(s.getOutputStream());
          
         System.out.println("Creating a new handler for this client...");

         TheClientHandler mtch = new TheClientHandler(s,"client " + noOfClients, dinputs, doutputs);

         Thread t = new Thread(mtch);
          
         System.out.println("Adding this client to active client list");

         clients.add(mtch);
         t.start();
         noOfClients++;
     }
 }
}