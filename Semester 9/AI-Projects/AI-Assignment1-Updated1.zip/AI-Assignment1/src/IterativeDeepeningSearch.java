import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

public class IterativeDeepeningSearch extends AbstractSearch{

	private DepthFirstSearch DF = new DepthFirstSearch();
	public static ArrayList<String> Solution = null;
	
	public ArrayList<Node> depthLimitedSearch(LinkedList<Node> queue, EndGame problem, int limit){
		
		plan = new ArrayList<>();
		solution = null;
		done = false;
		while(!done) {
			if(queue.isEmpty()) { //return failure if the queue is empty
//				System.out.println("FAILURE 1: there is no solution to this problem");
				done = true;
			}
			else { //if the queue is not empty, remove the node according to the search algorithm used
				currNode = queue.remove(queue.size()-1); //remove node from the end of the queue
				
				if(!currNode.isRootNode()) { //if the node is not the initial state, update the problem's grid, adjacency list and iron man's damage
					String operator = currNode.getOperator();
					
					problem.updateGridAndAdjacencyList(currNode, operator);
					problem.updateDamage(currNode.getParent(), operator, currNode);
				//	this.queue = problem.updateQueue(this.queue, currNode, operator);
					problem.updateIronManPosition(currNode, operator);
				}
								
				plan.add(currNode);
				
				problem.visualize(visualize, currNode); //visualize grid
				
				if(problem.isGoal(currNode)) { //apply the goal test and return the node if the test succeeds
					System.out.println("SUCCESS: goal reached");
					solution = plan;
					done = true;
				}
				else { //if it fails the goal test, expand the node further
					if(currNode.getDepth() < limit) { //the node will only be expanded if it is within the depth limit
						ArrayList<Node> expandedNodes = this.expand(currNode, problem);
						
						for(int i = 0 ; i < expandedNodes.size() ; i++) {	
							queue.add(expandedNodes.get(i)); //add expanded nodes to the queue
						}
					}
					else {
						return solution;
					}
				}
			}
		}
		
		return solution;
	}
	
	public ArrayList<Node> iterativeDeepeningSearch(LinkedList<Node> queue, EndGame problem) {
		
		int depthCurrent = 0;
		ArrayList<Node> Solution = null;
		LinkedList<Node> queueTemp = new LinkedList<>();
				
		while(Solution == null) 
		{
//			System.out.println("DepthCurrent: " + depthCurrent);
			Solution = depthLimitedSearch(queue, problem, depthCurrent++);
			
			problem = problem.restartGame();
			
			visited.clear();		
			visited.add(new Node(problem.getInitialState()));
						
			queue.clear();
			queue.add(new Node(problem.getInitialState()));
			
			if(Solution != null)
				return Solution;
		
		}
		return Solution;
		
	}

}
