import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  myBooks: any[];
  isbns: any[];
  name: String;
  username: String = "khadija";
  user: any[];
  regular_user: boolean;
  newBookForm: FormGroup;
  tomorrow: String;
  
constructor(private bookService: BookService){
  this.newBookForm = new FormGroup({
    title: new FormControl(),
    cover: new FormControl(),
    description: new FormControl(),
    isbn: new FormControl()
 });
}



    ngOnInit() {
     
      this.username = this.bookService.returnCurrentUser();

      this.bookService.getUser(this.username)
      .subscribe(
        (data) => {
          this.user = data.data;
          this.name = this.user[0].name;
          
          if(this.user[0].type == "regular_user"){
            this.regular_user = true;   
          }
          else{
            this.regular_user = false;
          }
          //console.log(this.user[0].name);
        },
        (error) => console.log(error)
      );
      //console.log(this.username);

      this.bookService.getBorrowedBooks()
      .subscribe(
        (data) => {
          this.myBooks = data.data;

          console.log(this.myBooks); 
          this.myBooks.forEach(book => {
            var tomorrowDate = new Date();
            tomorrowDate.setDate(tomorrowDate.getDate()+1);
            var tomorrowDay = tomorrowDate.toString();
            var res1 = tomorrowDay.split(" ");

            var bookReturnDate = book[5];
            var res = bookReturnDate.split(" ");

            if(res1[2] == res[2]){
                this.bookService.notifyUserDeadline(book[0]);
            }

            var currentDate = new Date();
            var currentDay = currentDate.toString();
            var res3 = currentDay.split(" ");

            if(res3[2].localeCompare(res[2]) > 0){
              console.log("met2akhar yad");
              this.bookService.notifyUserMoney("100",book[0]);
          }
          
          })

        },
        (error) => console.log(error)
      );

       //console.log(this.myBooks); 

        
      

    }

    onAddBook(){
      this.bookService.registerBook(this.newBookForm.value.title,this.newBookForm.value.cover,this.newBookForm.value.description,this.newBookForm.value.isbn,3);
      console.log("7ot el ketab naw");
      this.bookService.notifyUsersWithNewBook(this.newBookForm.value.title);
    }
}