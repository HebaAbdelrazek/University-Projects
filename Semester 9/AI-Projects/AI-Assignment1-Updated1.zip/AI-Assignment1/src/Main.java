import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue; 
import java.util.Timer;

public class Main{
	
	public static String solve(String grid, String strategy, boolean visualize) {
		String solution = "";
		
		EndGame problem = new EndGame(grid);
		
		AbstractSearch as = new AbstractSearch();
		ArrayList<Node> sol = as.solve(problem, strategy, visualize);
		
//		if(sol != null)
//			solution = sol.solution();
		if(sol != null) {
			for(int i = 1 ; i < sol.size() ; i++) {
				if(i == sol.size()-1)
					solution+=sol.get(i).getOperator();
				else
					solution+=sol.get(i).getOperator()+",";
			}
			
			if(sol.size() > 0)
				solution+=";"+problem.damage+";"+sol.size();
		}
		
		return solution;
	}
	public static void main(String[]args) {
		Main main = new Main();
		
		String sol = main.solve("5,5;2,2;4,2;4,0,1,2,3,0,2,1,4,1,2,4;3,2,0,0,3,4,4,3,4,4", "DF", true);
		
		System.out.println(sol);
		//love you dajdaj
	}

}
