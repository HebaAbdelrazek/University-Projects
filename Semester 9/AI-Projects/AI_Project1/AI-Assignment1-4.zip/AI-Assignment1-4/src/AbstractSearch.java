import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;

public class AbstractSearch {
	
	static int numberOfExpandedNodes;
	
	static Node initialState;
	static Node currNode;
	static Node solution;
	
	static int heuristic;
	
	static LinkedList<Node> queue;
	static PriorityQueue<Node> pQueue;
	
	DepthFirstSearch DF;
	BreadthFirstSearch BF;
	UniformCostSearch UC;
	IterativeDeepeningSearch ID;
	GreedySearch GR;
	AStarSearch AS;
	
	boolean done;
	
	static boolean visualize;
	
	public String strategy;
		
	public EndGame problem;
	HashSet<String> repeatedStates;
	
	public AbstractSearch() {
		numberOfExpandedNodes = 0;
		
		repeatedStates = new HashSet<String>();
		queue = new LinkedList<>();
		pQueue = new PriorityQueue<>();
		heuristic = -1;
		
		strategy = "";
		
	}

	public Node solve(EndGame problem, String strategy) { //returns a node containing the path to the destination
		
		this.strategy = strategy;
		
		this.problem = problem;
		
		this.visualize = visualize;
		
		if(strategy == "DF") {
			DF = new DepthFirstSearch();	
		}
		else if(strategy == "BF") {
			BF = new BreadthFirstSearch();
		}
		else if(strategy == "UC") {
			UC = new UniformCostSearch();
		}
		else if(strategy == "ID") {
			ID = new IterativeDeepeningSearch();
		}
		else if(strategy == "GR1" || strategy == "GR2") {
			GR = new GreedySearch(strategy);
		}
		else if(strategy == "AS1" || strategy == "AS2") {
			AS = new AStarSearch(strategy);
		}
		
		State initState = new State(problem.warriorsArray, problem.stonesArray, problem.ironManArray);
		
		initialState = new Node(initState); //make initial state a node
		
		problem.setInitialState(initialState);
		
		if(strategy == "DF" || strategy == "ID" || strategy == "BF")
			queue.add(initialState);
		else
			pQueue.add(initialState); //add initial state to the queue
				
		if(strategy == "GR1" || strategy == "AS1") {
			heuristic = 1;
			initialState.setHeuristic(1, problem);
		}
		else if(strategy == "GR2" || strategy == "AS2") {
			heuristic = 2;
			initialState.setHeuristic(2, problem);
		}
		
		if(strategy == "DF") {
			solution = DF.depthFirstSearch(queue, problem);					
		}
		else if(strategy == "BF") {
			solution = BF.breadthFirstSearch(queue, problem);
		}
		else if(strategy == "UC") {
			solution = UC.uniformCostSearch(pQueue, problem);
		}
		else if(strategy == "ID") {
			solution = ID.iterativeDeepeningSearch(queue, problem);
		}
		else if(strategy == "GR1" || strategy == "GR2") {
			solution = GR.greedySearch(pQueue, problem);
		}
		else if(strategy == "AS1" || strategy == "AS2") {
			solution = AS.aStarSearch(pQueue, problem);
		}
			
		return solution;
	}
	
	public ArrayList<Node> expand(Node currNode, EndGame problem){
		ArrayList<Node> expandedNodes = new ArrayList<Node>();
		
		ArrayList<String> operations = problem.getOperations(currNode.getState()); //get all possible operations for the current node
		
		for(int i = 0 ; i < operations.size() ; i++) { //for each operation, get the next state, create its node, and add it to the expanded nodes
			State nextState = problem.getNextState(currNode.getState(), operations.get(i));
			
			Node newNode;
			if(strategy.equals("GR1") || strategy.equals("GR2"))
				newNode = new GreedyNode(nextState, currNode, operations.get(i), problem.getStepCost(operations.get(i), nextState));
			else if(strategy.equals("AS1") || strategy.equals("AS2"))
				newNode = new AStarNode(nextState, currNode, operations.get(i), problem.getStepCost(operations.get(i), nextState));
			else
				newNode = new Node(nextState, currNode, operations.get(i), problem.getStepCost(operations.get(i), nextState));
			
			if(!this.repeatedStates.contains(newNode.getState().toString())){
				expandedNodes.add(newNode);
			}
			
			boolean visitedFlag = false;
			
		}
		
		return expandedNodes;
	}
	
}
