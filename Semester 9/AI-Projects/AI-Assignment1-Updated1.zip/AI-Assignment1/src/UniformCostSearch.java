import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

public class UniformCostSearch extends AbstractSearch{

	public ArrayList<Node> uniformCostSearch(LinkedList<Node> queue, EndGame problem) {
		done = false;
		while(!done) {
			if(queue.isEmpty()) { //return failure if the queue is empty
				System.out.println("FAILURE 1: there is no solution to this problem");
				done = true;
			}
			else { //if the queue is not empty, remove the node according to the search algorithm used
				for (int i = 0; i < queue.size()-1; i++)           
				    for (int j = 0; j < queue.size()-i-1; j++)  
				        if (queue.get(j).getPathCost() > queue.get(j+1).getPathCost()) {
				        		Node tmp = queue.get(j);
				        		queue.set(j, queue.get(j+1));
				        		queue.set(j+1, tmp);
				        }
				
				for(int i = 0 ; i < queue.size() ; i++)
					System.out.print(queue.get(i).getPathCost() + " ");
				
				Node currNode = queue.remove(0);
				
				System.out.println("taken node: " + currNode.getPathCost());
				
				if(!currNode.isRootNode()) { //if the node is not the initial state, update the problem's grid, adjacency list and iron man's damage
					String operator = currNode.getOperator();
					
					problem.updateGridAndAdjacencyList(currNode, operator);
					problem.updateDamage(currNode.getParent(), operator, currNode);
//					this.queue = problem.updateQueue(this.queue, currNode, operator);
					problem.updateIronManPosition(currNode, operator);
				}
								
				plan.add(currNode);
				
				problem.visualize(visualize, currNode); //visualize grid
				
				if(problem.isGoal(currNode)) { //apply the goal test and return the node if the test succeeds
					System.out.println("SUCCESS: goal reached");
					solution = plan;
					done = true;
				}
				else { //if it fails the goal test, expand the node further
					ArrayList<Node> expandedNodes = this.expand(currNode, problem);
					
					for(int i = 0 ; i < expandedNodes.size() ; i++) {	
						queue.add(expandedNodes.get(i)); //add expanded nodes to the queue
					}
				}
				
			}
		}
		
		return solution;
	
	}
	
	public static void main(String[]args) {
		
//		ArrayList<Integer> array = new ArrayList<>();
//		ArrayList<Integer> temp = new ArrayList<>();
//		
//		array.add(3);
//		array.add(4);
//		array.add(1);
//		array.add(7);
//		array.add(5);
//		array.add(2);
		
//		for(int i = 0 ; i < array.size() ; i++) {
//			System.out.print(array.get(i) + " ");
//		}
		
//		int maxValue = -1;
//		int maxIndex = 0;
		
		//sort queue from lowest cost to highest cost
//		while(!array.isEmpty()) {
//			for(int j = 0 ; j < array.size() ; j++) {
//				if(array.get(j).compareTo((Integer)maxValue) == 1) {
//					maxValue = array.get(j);
//					maxIndex = j;
//				}	
//			}
//			temp.add(maxValue);
//			
//			array.remove(maxIndex);
//			maxValue = -1;
//		}
//		
//		for(int i = 0 ; i < temp.size() ; i++) {
//			System.out.print(temp.get(i) + " ");
//		}
//		
	}

}
