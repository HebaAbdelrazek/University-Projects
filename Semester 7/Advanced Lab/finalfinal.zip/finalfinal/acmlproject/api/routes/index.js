var express = require('express'),
  router = express.Router();

var mongoose = require('mongoose');
var User = mongoose.model('User');
var Book = mongoose.model('Book');
var Notification = mongoose.model('Notification');

userCtrl = require('../controllers/UserController');
bookCtrl = require('../controllers/BookController');
notificationCtrl = require('../controllers/NotificationController');

// USER ROUTES
router.post('/api/registerUser', userCtrl.register_user);
router.get('/api/getUsers', userCtrl.getUsers);
router.get('/api/getUser:username', userCtrl.getUserByUsername);
router.get('/api/getBorrowedBooks:username', userCtrl.getBorrowedBooks);
router.put('/api/addBorrowedBooks:username', userCtrl.addBorrowedBooks);
// router.delete('/api/User/deleteAccount/:userName', userCtrl.deleteUser);

//BOOK ROUTES
router.post('/api/registerBook', bookCtrl.register_book);
router.get('/api/getBooks', bookCtrl.getBooks);
router.get('/api/getBook:isbn', bookCtrl.getBookByISBN);
router.put('/api/updateCopies:isbn', bookCtrl.updateCopies);

//NOTIFICATION ROUTES
router.post('/api/notifyUsersWithNewBook', notificationCtrl.createNotification);
router.post('/api/notifyUserDeadline', notificationCtrl.createNotification);
router.post('/api/notifyUserMoney', notificationCtrl.createNotification);
router.get('/api/getNotifications', notificationCtrl.getNotifications);
router.get('/api/getNotificationsBorrowedBooks:username', notificationCtrl.getNotificationsBorrowedBooks);
module.exports = router;
