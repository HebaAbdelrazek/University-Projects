const app = document.getElementById('root');

//logo
// const logo = document.createElement('img');
// logo.src = '/Users/khaledhammoud/Downloads/533B4FA3-8F59-4C14-8AD2-9B40F17F3B82.JPG';

const container = document.createElement('div');
container.setAttribute('class', 'container');

//app.appendChild(logo);
app.appendChild(container);

var request = new XMLHttpRequest();
request.open('GET', 'https://api.itbook.store/1.0/search/new', true);

request.onload = function () {

  // Begin accessing JSON data here
  var data = JSON.parse(this.response);
  if (request.status >= 200 && request.status < 400) {
    data.books.forEach(book => {
      const card = document.createElement('div');
      card.setAttribute('class', 'card');

      const h1 = document.createElement('h1');
      h1.textContent = book.title;

      const h2 = document.createElement('img');
      h2.src = book.image;

      var button = document.createElement("button");
      button.innerHTML = "Check Description";

      card.appendChild(button);
      container.appendChild(card);
      card.appendChild(h1);
      card.appendChild(h2);
      button.addEventListener ("click", function() {
        setTimeout('window.location.href="bookDescription.html"', 0);
      });

    });
  } else {
    const errorMessage = document.createElement('marquee');
    errorMessage.textContent = `Gah, it's not working!`;
    app.appendChild(errorMessage);
  }
}

request.send();
