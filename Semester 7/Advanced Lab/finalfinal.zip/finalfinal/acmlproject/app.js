
require('./api/config/DBConnection');

// https://stackoverflow.com/questions/20832126/missingschemaerror-schema-hasnt-been-registered-for-model-user#27540516
require('./api/models/User.js');
//require('./api/models/Review.js');
//import { check } from './api/controllers/OfficeHoursSessionsController';

var express = require('express'),
  config = require('./api/config'),
  logger = require('morgan'),
  cors = require('cors'),
  helmet = require('helmet'),
  compression = require('compression'),
  cookieParser = require('cookie-parser'),
  bodyParser = require('body-parser'),
  localStrategy = require('passport-local').Strategy,
  mongoose = require('mongoose'),
  passport = require('passport'),
  path = require('path'),
  routes = require('./api/routes'),

  app = express(),
  http = require('http').Server(app);
                                    
  var server = http.listen(process.env.PORT || 3000, function () {
    var port = server.address().port;
    console.log("App now running on port", port);
  });
  
  app.set('secret', config.SECRET);
  
  app.use(logger(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
  app.use(
    cors({
      origin: true,
      credentials: true,
      methods: ['GET', 'POST', 'PATCH', 'DELETE']
    })
  );


  app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    req.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    next();
  });

//   app.all('/*', function (req, res, next) {
//     res.header("Access-Control-Allow-Origin", "http://localhost:3000");
//     res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
//     res.header("Access-Control-Allow-Headers", "X-Requested-With,     Content-Type");
//     next();
// });

  app.use(helmet());
  app.use(compression());
  app.use(bodyParser.json());
  app.use(
    bodyParser.urlencoded({
      extended: true
    })
  );
  app.use(cookieParser());
  app.use(require('express-session')({
      secret: config.SECRET,
      resave: false,
      saveUninitialized: false
  }));
  app.use(passport.initialize());
  app.use(passport.session());
  app.use(express.static(path.join(__dirname, 'public')));
  app.use('', routes);

// Configure passport
User = mongoose.model('User');
// passport.use(new localStrategy(User.authenticate()));
// passport.serializeUser(User.serializeUser());
// passport.deserializeUser(User.deserializeUser());User = mongoose.model('User');


// 500 internal server error handler
app.use((err, req, res, next) => {
  if (err.statusCode === 404) return next();
  res.status(500).json({
    // Never leak the stack trace of the err if running in production mode
    err: process.env.NODE_ENV === 'production' ? null : err.message,
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    msg: '500 Internal Server Error',
    data: null
  });
});

// 404 error handler
app.use((req, res) => {
  res.status(404).json({
    err: null,
    msg: '404 Not Found',
    data: null
  });
});

module.exports = app;
