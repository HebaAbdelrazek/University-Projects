var mongoose = require('mongoose'),
moment = require('moment'),
Validations = require('../utils/Validations');
const Book = mongoose.model('Book');
//passport = require('passport');
//notifications = mongoose.model('Notification'),
//nodemailer = require('nodemailer');

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

module.exports.register_book = function (req, res, next){
    
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("acmlproject");
        var book = req.body;
        dbo.collection("books").insertOne(book, function(err, res) {
          if (err) 
            console.log("This book already exists");
          else
            console.log("Book registered successfulyy");
          db.close();
        });
      });
  };

  module.exports.getBooks = async (req, res) => {
    console.log("ahlan");
    
    const books = await Book.find({}).exec();
    
      if(!books){
          return res.status(404).json({ msg: 'Books not found', data: null });
      
        }
        return res.status(200).json({
          err: null,
          msg: 'Books retrieved successfully',
          data: books
        });
  };
  

  module.exports.getBookByISBN = async (req, res) => {
    console.log("hoi");
    var isbn = req.params.isbn;
    console.log(isbn);
    const book = await Book.find({"isbn" : isbn}).exec();
  
    if(!book){
        return res.status(404).json({ msg: 'Book not found', data: null });
    
      }
      return res.status(200).json({
        err: null,
        msg: 'Book retrieved successfully',
        data: book
      });
  };

   module.exports.updateCopies= async (req, res) => {
    
    console.log("meow");
    var isbn = req.params.isbn;
    const edited = await Book.update(
        {"isbn" : isbn},
        {
          $set:{
            copies: req.body.copies
          }
        }
      ).exec();
      if (!edited) {
        return res
          .status(404)
          .json({ err: null, msg: 'not found.', data: null });
      }
      res.status(200).json({
        err: null,
        msg: 'updated successfully.',
        data: edited
      });
     };

