package networksmedia;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.border.Border;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUI extends JFrame{
	
	public JTextField textField;
	public JButton btnSend;
	public JLabel lblNewLabel;
	public boolean didSend;
	public GUI() {
		getContentPane().setLayout(null);
		
		btnSend = new JButton("Send");
		btnSend.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				
				didSend = true;
				
			}
		});
		btnSend.setBounds(262, 205, 97, 25);
		getContentPane().add(btnSend);
		
		textField = new JTextField();
		textField.setBounds(29, 205, 211, 23);
		getContentPane().add(textField);
		textField.setColumns(10);
		
	    lblNewLabel = new JLabel("Chat goes here...");
		lblNewLabel.setFont(new Font("Sitka Small", Font.PLAIN, 13));
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBackground(new Color(255, 175, 175));
		lblNewLabel.setBounds(27, 32, 193, 147);
		Border b = BorderFactory.createLineBorder(Color.BLUE,5);
		lblNewLabel.setBorder(b);
		getContentPane().add(lblNewLabel);
		
	
	}
}
