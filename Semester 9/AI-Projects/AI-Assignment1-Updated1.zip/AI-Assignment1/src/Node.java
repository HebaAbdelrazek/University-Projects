import java.util.ArrayList;
import java.util.List;

public class Node { //a class that represents a node with all of its information
	
	private State state;
    private Node parent;
    private String operator;
    public int pathCost;
    private int depth;
    private int hCost;
    
    public Node(State state) { //if it's the root node
    		this.state = state;
    		this.pathCost = 0;
    		this.depth = 0;
    		this.parent = null;
    		this.hCost = -1;
    		
    }
    
	public Node(State state, Node parent, String operator, int stepCost) { //if it's not the root node
    		this.state = state;
    		this.parent = parent;
    		this.operator = operator;
    		this.pathCost = parent.pathCost + stepCost;
    		this.depth = 0;
    		this.hCost = -1;
    		
    		Node node = parent;
    		while(node != null) {
    			node = node.getParent();
    			depth++;
    		}
    }
	
	public State getState() {
		return state;
	}

	public Node getParent() {
		return parent;
	}

	public String getOperator() {
		return operator;
	}

	public int getPathCost() {
		return pathCost;
	}
	
	public int getDepth() {
		return depth;
	}
	
	public int getHeuristic() {
		return hCost;
	}
	public EndGame getEndGame() {
		return state.endGameInstance;
	}
	public void setEndGame(EndGame endGameInstance) {
		 this.state.endGameInstance = endGameInstance;
	}
	public void setHeuristic(int strategy, EndGame problem) {	//3ASHAN LESSA MA7ASALSH 7AGA
		int hCost = 0;
		
		if(strategy == 1) {
//			ArrayList<ArrayList<Integer>> stonesPositions = new ArrayList<ArrayList<Integer>>();
//			ArrayList<Integer> ironManPosition = new ArrayList<>();
//			
//			ironManPosition.add(problem.ironManArray.get(1));
//			ironManPosition.add(problem.ironManArray.get(2));
//			
//			for(int i = 0 ; i < problem.stonesArray.size() ; i++) {
//				ArrayList<Integer> tmp = new ArrayList<>();
//				tmp.add(problem.stonesArray.get(i).get(1));
//				tmp.add(problem.stonesArray.get(i).get(2));
// 				stonesPositions.add(tmp);
//				
//			}
//			
//			if(!this.isRootNode()) {
//				if(operator.equals("collect")) {
//					for(int i = 0 ; i < problem.stonesArray.size() ; i++) {
//						if(problem.stonesArray.get(i).get(0).equals(problem.ironManArray.get(0)))
//							stonesPositions.remove(i);
//						
//					}
//				}
//				else if(operator.equals("left")) {
//					ironManPosition.set(1, ironManPosition.get(1)-1);
//				}
//				else if(operator.equals("right")) {
//					ironManPosition.set(1, ironManPosition.get(1)+1);
//				}
//				else if(operator.equals("up")) {
//					ironManPosition.set(0, ironManPosition.get(0)-1);
//				}
//				else if(operator.equals("down")) {
//					ironManPosition.set(0, ironManPosition.get(0)+1);
//				}
//			}
//			System.out.println("n: " + stonesPositions.size());
//			
//			for(int i = 0 ; i < stonesPositions.size() ; i++) {
//				hCost += Math.abs(ironManPosition.get(0) - stonesPositions.get(i).get(0)) + Math.abs(ironManPosition.get(1) - stonesPositions.get(i).get(1));
//				
//			}
//			hCost += Math.abs(ironManPosition.get(0) - problem.thanosArray.get(1)) + Math.abs(ironManPosition.get(1) - problem.thanosArray.get(2));
			ArrayList<Integer> ironManPosition = new ArrayList<>();
			
			ironManPosition.add(problem.ironManArray.get(1));
			ironManPosition.add(problem.ironManArray.get(2));
			ArrayList<ArrayList<Integer>> stonesPositions = new ArrayList<ArrayList<Integer>>();
			
			for(int i = 0 ; i < problem.stonesArray.size() ; i++) {
				ArrayList<Integer> tmp = new ArrayList<>();
				tmp.add(problem.stonesArray.get(i).get(1));
				tmp.add(problem.stonesArray.get(i).get(2));
 				stonesPositions.add(tmp);
				
			}
			
			if(!this.isRootNode()) {
				if(operator.equals("collect")) {
					for(int i = 0 ; i < problem.stonesArray.size() ; i++) {
						if(problem.stonesArray.get(i).get(0).equals(problem.ironManArray.get(0)))
							stonesPositions.remove(i);
						
					}
				}
				
				
				
				if(operator.equals("left")) {
					ironManPosition.set(1, ironManPosition.get(1)-1);
				}
				else if(operator.equals("right")) {
					ironManPosition.set(1, ironManPosition.get(1)+1);
				}
				else if(operator.equals("up")) {
					ironManPosition.set(0, ironManPosition.get(0)-1);
				}
				else if(operator.equals("down")) {
					ironManPosition.set(0, ironManPosition.get(0)+1);
				}
			}
			int thanosCost = 10;
			
			if(!isRootNode()) {
				for(int i = 0 ; i < 4 ; i++) {
					if(problem.adjacencyList[problem.ironManArray.get(0)][i] == problem.thanosState)
						thanosCost = 5;
				}
				if(operator.equals("snap")) { //ironman is in thanos cell
					thanosCost = 0;
				}
			}
			
			
			//(ironManPosition.get(0) == problem.thanosArray.get(1)) && (ironManPosition.get(1) == problem.thanosArray.get(2))
			hCost= stonesPositions.size()*3 + thanosCost;
			System.out.println("stones positions size" + stonesPositions.size());
		}
		else if(strategy == 2) {
			ArrayList<Integer> ironManPosition = new ArrayList<>();
			
			ironManPosition.add(problem.ironManArray.get(1));
			ironManPosition.add(problem.ironManArray.get(2));
			ArrayList<ArrayList<Integer>> stonesPositions = new ArrayList<ArrayList<Integer>>();
			
			for(int i = 0 ; i < problem.stonesArray.size() ; i++) {
				ArrayList<Integer> tmp = new ArrayList<>();
				tmp.add(problem.stonesArray.get(i).get(1));
				tmp.add(problem.stonesArray.get(i).get(2));
 				stonesPositions.add(tmp);
				
			}
			
			if(!this.isRootNode()) {
				if(operator.equals("collect")) {
					for(int i = 0 ; i < problem.stonesArray.size() ; i++) {
						if(problem.stonesArray.get(i).get(0).equals(problem.ironManArray.get(0)))
							stonesPositions.remove(i);
						
					}
				}
				
				
				
				if(operator.equals("left")) {
					ironManPosition.set(1, ironManPosition.get(1)-1);
				}
				else if(operator.equals("right")) {
					ironManPosition.set(1, ironManPosition.get(1)+1);
				}
				else if(operator.equals("up")) {
					ironManPosition.set(0, ironManPosition.get(0)-1);
				}
				else if(operator.equals("down")) {
					ironManPosition.set(0, ironManPosition.get(0)+1);
				}
			}
			int thanosCost = 1;
			
			if(!isRootNode()) {
				if(operator.equals("snap")) { //ironman is in thanos cell
					thanosCost = 0;
				}
			}
			
			
			//(ironManPosition.get(0) == problem.thanosArray.get(1)) && (ironManPosition.get(1) == problem.thanosArray.get(2))
			hCost= stonesPositions.size()*3 + thanosCost;
			System.out.println("stones positions size" + stonesPositions.size());
		}
//		System.out.println("hCost: " + hCost);
		
		this.hCost = hCost;
	}
	
	public boolean isRootNode() { //if the node does not have a parent, then it is the root node
		return parent == null;
	}
	
	public String plan(ArrayList<Node> p){
		List<Node> temp = new ArrayList<>();
		Node current = this;
		
		//we go through the path from the bottom up until the root node
		while(!current.isRootNode()) { 
			temp.add(0, current); //add node to the start of the list
			current = current.getParent();
		}
		
		//adding the root node to the start of the list
		temp.add(0, current);
		
		String operatorsFromRoot = "";
		
		for(int i = 0 ; i < temp.size() ; i++) {
			if(i == temp.size()-1)
				operatorsFromRoot+=temp.get(i);
			else
				operatorsFromRoot+=temp.get(i)+",";
		}
			
		
		return operatorsFromRoot;
	}
	
	
	public ArrayList<Node> getPathFromRoot(){
		ArrayList<Node> path = new ArrayList<Node>();
		Node current = this;
		
		//we go through the path from the bottom up until the root node
		while(!current.isRootNode()) { 
			path.add(0, current); //add node to the start of the list
			current = current.getParent();
		}
		
		//adding the root node to the start of the list
		path.add(0, current);
		return path;
	}
	
	public String toString() {
		return "State: " + this.state + "\n" + "Parent: " + this.parent + "\n" + "Operator: " + this.operator + "\n" + "Path Cost: " + this.pathCost;
	}
	
	public String solution(ArrayList<Node> p) {
		String solution = plan(p);
		
		List<Node> path = this.getPathFromRoot();
		
		solution+=";"+this.getPathCost()+";"+path.size();
		
//		for(int i = 0 ; i < path.size() ; i++) {
//			pathString+=path.get(i).getState() + " ";
//		}
		
		return solution;
	}


}
