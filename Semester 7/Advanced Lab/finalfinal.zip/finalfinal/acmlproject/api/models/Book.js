//var encrypt = require('../utils/Encryption.js'),
var mongoose = require('mongoose');
//passportLocalMongoose = require('passport-local-mongoose');

//require('mongoose-type-email');


var bookSchema = mongoose.Schema({
title: {
    type: String,
    required: true,
    unique: true
},
cover: {
  type: String
},
description: {
    type: String,
    required: true
},
isbn: {
    type: String,
    required: true
},
copies: {
    type: Number,
    required: true
}

});

//userSchema.set('autoIndex',false);
//userSchema.plugin(passportLocalMongoose);

module.exports = mongoose.model('Book', bookSchema);
