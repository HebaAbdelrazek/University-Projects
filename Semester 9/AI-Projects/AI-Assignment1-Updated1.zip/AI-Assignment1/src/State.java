import java.util.ArrayList;

public class State{ //each state has an id and may or may not have one of ["T", "I", "S", "W", "E"] 
																							//"E" indicates that the state is empty
	
	public String id;
	public String element;
	public EndGame endGameInstance;
	
	public State(String id, EndGame endGameInstance) {
		this.id = id;
		this.element = "E";
		this.endGameInstance = new EndGame(endGameInstance.grid);
//		this.endGameInstance.adjacencyList= endGameInstance.adjacencyList;
//		this.endGameInstance.initialState = endGameInstance.initialState;
//		this.endGameInstance.thanosState = endGameInstance.thanosState;
//		this.endGameInstance.damage = endGameInstance.damage;
//		this.endGameInstance.stonesCollected = endGameInstance.stonesCollected;
//		this.endGameInstance.gridArray = endGameInstance.gridArray;
//		this.endGameInstance.adjacencyList = endGameInstance.adjacencyList;
//		this.endGameInstance.stonesArray = endGameInstance.stonesArray;
//		this.endGameInstance.ironManArray = endGameInstance.ironManArray;
//		this.endGameInstance.thanosArray = endGameInstance.thanosArray;
		
		
		
	}
	
	public boolean equals(Node node) {
		return node.getState().getId().equals(this.id) && node.getEndGame().equals(this.endGameInstance);
	}
	
	public String getId() {
		return id;
	}
	
	public String getElement() {
		return element;
	}
	
	public void setElement(String element) {
		this.element = element;
	}
	
	public String toString() {
		return id;
	}

}
