import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

public class EndGame extends AbstractSearch implements Problem{
	public State initialState;
	public State thanosState;
	
	public String grid;
	
	public int damage;
	public int stonesCollected;
	
	public Node[][] gridArray;
	
	public State[][] adjacencyList;
	
	public ArrayList<ArrayList<Integer>> stonesArray; //array list that carries each stone's id and x and y coordinates
	public ArrayList<Integer> thanosArray; //array list that carries thanos's id and x and y coordinates
	public ArrayList<Integer> ironManArray;
	
	public Node[][] initialGridArray; //to save the initial grid state
	public State[][] initialAdjacencyList; //to save the initial adjacency list state
	
	public ArrayList<Node> visited;
	
	public EndGame(String grid) {
		
		visited = new ArrayList<Node>();
		
		this.grid = grid;
		//INITIALIZE GRID
		System.out.println(grid);
		String[] gridTemp = grid.split(";");
		
		String[] rowsAndColumns = gridTemp[0].split(",");
		int rows = Integer.parseInt(rowsAndColumns[0]);
		int columns = Integer.parseInt(rowsAndColumns[1]);
		
		//setting the dimensions of the grid
		gridArray = new Node[rows][columns];	
		
		//creating a node in each element and setting the number of its state
		int count = 0;
		for(int i = 0 ; i < gridArray.length ; i++) {
			for(int j = 0 ; j < gridArray.length ; j++) {
				gridArray[i][j] = new Node(new State(""+count,this));
				count++;
			}
		}
		
		//adding iron man to the grid
		String[] ironMan = gridTemp[1].split(",");
		
//		((State) gridArray[Integer.parseInt(ironMan[0])][Integer.parseInt(ironMan[1])].getState()).setElement(1, "I"); 	
		
		this.initialState = (State) (gridArray[Integer.parseInt(ironMan[0])][Integer.parseInt(ironMan[1])].getState()); //setting our iron man state as our initial state
		
		ironManArray = new ArrayList<>();
		ironManArray.add(Integer.parseInt(gridArray[Integer.parseInt(ironMan[0])][Integer.parseInt(ironMan[1])].getState().getId())); //add iron man id
		ironManArray.add(Integer.parseInt(ironMan[0])); //add iron man x coordinate
		ironManArray.add(Integer.parseInt(ironMan[1])); //add iron man y coordinate
		
		//adding thanos to the grid
		String[] thanos = gridTemp[2].split(",");
		
		((State) gridArray[Integer.parseInt(thanos[0])][Integer.parseInt(thanos[1])].getState()).setElement("T");
		
		this.thanosState = (State) (gridArray[Integer.parseInt(thanos[0])][Integer.parseInt(thanos[1])].getState());
		
		thanosArray = new ArrayList<>();
		thanosArray.add(Integer.parseInt(gridArray[Integer.parseInt(thanos[0])][Integer.parseInt(thanos[1])].getState().getId())); //add thanos id
		thanosArray.add(Integer.parseInt(thanos[0])); //add thanos x coordinate
		thanosArray.add(Integer.parseInt(thanos[1])); //add thanos y coordinate
		
		//adding the stones to the grid
		String[] stones = gridTemp[3].split(",");
		
		stonesArray = new ArrayList<ArrayList<Integer>>();
		
		for(int i = 0 ; i < stones.length-1 ; i+=2) {
			((State) gridArray[Integer.parseInt(stones[i])][Integer.parseInt(stones[i+1])].getState()).setElement("S");
			
			ArrayList<Integer> tmp = new ArrayList<>();
			tmp.add(Integer.parseInt(gridArray[Integer.parseInt(stones[i])][Integer.parseInt(stones[i+1])].getState().getId())); //add id
			tmp.add(Integer.parseInt(stones[i])); //add x coordinate
			tmp.add(Integer.parseInt(stones[i+1])); //add y coordinate
			
			stonesArray.add(tmp);
		}	
		
		//adding the warriors to the grid
		String[] warriors = gridTemp[4].split(",");
		
		for(int i = 0 ; i < warriors.length-1 ; i+=2) {
			((State) gridArray[Integer.parseInt(warriors[i])][Integer.parseInt(warriors[i+1])].getState()).setElement("W");
		}
		
		//making the adjacency list
		adjacencyList = new State[rows*columns][4];
		
		for(int i = 0 ; i < rows ; i++) {
			for(int j = 0 ; j < columns; j++) {
				if(j > 0) //left
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][0] = (State) gridArray[i][j-1].getState();
				else
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][0] = null;
				
				if(j < columns-1) //right
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][1] = (State) gridArray[i][j+1].getState();
				else
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][1] = null;
				
				if(i > 0) //up
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][2] = (State) gridArray[i-1][j].getState();
				else
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][2] = null;
				
				if(i < rows-1) //down
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][3] = (State) gridArray[i+1][j].getState();
				else
					adjacencyList[Integer.parseInt(((State) gridArray[i][j].getState()).getId())][3] = null;
			}
		}
		
		initialGridArray = new Node[rows][columns];
		initialAdjacencyList = new State[rows*columns][4];
		
		for(int i = 0 ; i < gridArray.length ; i++) {
			for(int j = 0 ; j < gridArray[0].length ; j++) {
				initialGridArray[i][j] = gridArray[i][j];
			}
		}
		
		for(int i = 0 ; i < adjacencyList.length ; i++) {
			for(int j = 0 ; j < adjacencyList[0].length ; j++) {
				initialAdjacencyList[i][j] = adjacencyList[i][j];
			}
		}
		
		this.damage = 0;
		this.stonesCollected = 0;
	}
	
	public State getInitialState() {
		return initialState;
	}

	@Override
	public boolean isGoal(Node node) {
		if(!node.isRootNode())
			return node.getOperator().equals("snap");
		return false;
	}

	@Override
	public ArrayList<String> getOperations(State state) {
		ArrayList<String> operations = new ArrayList<String>();
		
		boolean warriorFound = false;
		boolean snap = false;
		
		if(state.equals(thanosState)) {
			operations.add("snap"); 
		}
		
		for(int i = 0 ; i < 4 ; i++) {
			
			//iron man can only move to the cell where thanos is and snap his fingers only if his damage is < 100 and he collected all 6 stones
			if(adjacencyList[Integer.parseInt(state.getId())][i] != null 
					&& adjacencyList[Integer.parseInt(state.getId())][i].getElement().equals("T")
					&& damage < 100
					&& stonesCollected == 6
					) {
				System.out.println("snap here");
				switch(i) {
					case 0: operations.add("left"); break;
					case 1: operations.add("right"); break;
					case 2: operations.add("up"); break;
					case 3: operations.add("down"); break;
				}
			}
			
			//iron man can move to a cell if it is empty or if it has a stone
			if(adjacencyList[Integer.parseInt(state.getId())][i] != null 
					&& (adjacencyList[Integer.parseInt(state.getId())][i].getElement().equals("E") || adjacencyList[Integer.parseInt(state.getId())][i].getElement().equals("S"))) {
				
				switch(i) {
					case 0: operations.add("left"); break;
					case 1: operations.add("right"); break;
					case 2: operations.add("up"); break;
					case 3: operations.add("down"); break;
				}
			}
			
			//iron man can kill all warriors that are in cells adjacent to iron man (but iron man cannot move into those cell yet)
			if(!warriorFound) { //add only 1 kill operator for all warriors in adjacent cells
				if(adjacencyList[Integer.parseInt(state.getId())][i] != null 
						&& adjacencyList[Integer.parseInt(state.getId())][i].getElement().equals("W")) {
					operations.add("kill"); 
					warriorFound = true;
				}
			}
		}
		
		//iron man can collect a stone only if he is in the same cell as the stone
		if(state.getElement().equals("S")) {
			operations.add("collect");
		}
		
		
		
		return operations;
	}

	@Override
	public State getNextState(State state, String action) {
		
		if(action.equals("left")) { 
			return adjacencyList[Integer.parseInt(state.getId())][0];
		}
		else if(action.equals("right")) { 
			return adjacencyList[Integer.parseInt(state.getId())][1];
		}
		else if(action.equals("up")) { 
			return adjacencyList[Integer.parseInt(state.getId())][2];
		}
		else if(action.equals("down")) { 
			return adjacencyList[Integer.parseInt(state.getId())][3];
		}
		else if(action.equals("kill") || action.equals("collect")) { //remains in the same state after killing warrior or collecting stone
			return state;
		}
		else if(action.equals("snap")) { 
			return thanosState;
		}
		
		return null;
	}

	@Override
	public int getStepCost(State currState, String action, State nextState) {
		int cost = 0;
		
		if(!currState.equals(nextState)) { //actions that involve moving to another cell
			
			for(int i = 0 ; i < 4 ; i++) { //damage from moving to an adjacent cell
				if(adjacencyList[Integer.parseInt(nextState.getId())][i] != null 
						&& adjacencyList[Integer.parseInt(nextState.getId())][i].getElement().equals("W")) {
					cost+=1; //if a warrior is in an adjacent cell, damage increases by 1 unit
				}
				else if(adjacencyList[Integer.parseInt(nextState.getId())][i] != null 
						&& adjacencyList[Integer.parseInt(nextState.getId())][i].getElement().equals("T")) {
					cost+=5; //if thanos is in an adjacent cell, damage increases by 5 units
				}
				else if(currState.equals(thanosState)) {
					cost+=10; //if thanos is in an adjacent cell, damage increases by 5 units
				}
			}
		}
		else { //actions that involve remaining in the same cell
			
			if(action.equals("kill")) {
				int warriorsCount = 0;
				for(int i = 0 ; i < 4 ; i++) { //count of all nearby warriors
					if(adjacencyList[Integer.parseInt(currState.getId())][i] != null 
							&& adjacencyList[Integer.parseInt(currState.getId())][i].getElement().equals("W")) {
						warriorsCount+=1;
					}
				}
				
				cost+=2*warriorsCount; //killing warriors increases damage by 2 units per warrior
				
				for(int i = 0 ; i < 4 ; i++) { //damage from remaining in the same cell
					if(adjacencyList[Integer.parseInt(currState.getId())][i] != null 
							&& adjacencyList[Integer.parseInt(currState.getId())][i].getElement().equals("T")) {
						cost+=5; //if thanos is in an adjacent cell, damage increases by 5 units
					}
				}
			}
			else if(action.equals("collect")){
				cost+=3; //collecting stone increases damage by 3 units
				
				for(int i = 0 ; i < 4 ; i++) { //damage from remaining in the same cell
					if(adjacencyList[Integer.parseInt(currState.getId())][i] != null 
							&& adjacencyList[Integer.parseInt(currState.getId())][i].getElement().equals("W")) {
						cost+=1; //if a warrior is in an adjacent cell, damage increases by 1 unit
					}
					else if(adjacencyList[Integer.parseInt(currState.getId())][i] != null 
							&& adjacencyList[Integer.parseInt(currState.getId())][i].getElement().equals("T")) {
						cost+=5; //if thanos is in an adjacent cell, damage increases by 5 units
					}
				}
			}
		}
		
		return cost;
	}
	
	public void updateIronManPosition(Node currNode, String operator) {
		if(operator.equals("left")) {
			ironManArray.set(0, Integer.parseInt(currNode.getState().getId()));
			ironManArray.set(2, ironManArray.get(2)-1);
		}
		else if(operator.equals("right")) {
			ironManArray.set(0, Integer.parseInt(currNode.getState().getId()));
			ironManArray.set(2, ironManArray.get(2)+1);
		}
		else if(operator.equals("up")) {
			ironManArray.set(0, Integer.parseInt(currNode.getState().getId()));
			ironManArray.set(1, ironManArray.get(1)-1);
		}
		else if(operator.equals("down")) {
			ironManArray.set(0, Integer.parseInt(currNode.getState().getId()));
			ironManArray.set(1, ironManArray.get(1)+1);
		}
		else if(operator.equals("snap")) {
			ironManArray.set(0, Integer.parseInt(currNode.getState().getId()));
			ironManArray.set(1, thanosArray.get(1));
			ironManArray.set(2, thanosArray.get(2));
		}
	}
	
	public void updateStonesArray(Node currNode, String operator) {
		if(operator.equals("collect")) {
			for(int i = 0 ; i < stonesArray.size() ; i++) {
				if(stonesArray.get(i).get(0).equals(ironManArray.get(0)))
					stonesArray.remove(i);
			}
		}
	}
	
	public void updateGridAndAdjacencyList(Node currNode, String operator) {
		
		if(operator.equals("collect")) {
			for(int i = 0 ; i < gridArray.length ; i++) { //update grid
				for(int j = 0 ; j < gridArray[0].length ; j++) {
					if(gridArray[i][j] != null && gridArray[i][j].equals(currNode)) {
						gridArray[i][j].getState().setElement("E");
					}
				}
			}
			
			for(int i = 0 ; i < adjacencyList.length ; i++) { //update adjacency list
				for(int j = 0 ; j < adjacencyList[0].length ; j++) {
					if(adjacencyList[i][j] != null 
							&& adjacencyList[i][j].getId().equals(currNode.getState().getId()))
						adjacencyList[i][j].setElement("E");
				}
			}
			this.stonesCollected++;
		
		}
		
		else if(operator.equals("kill")) {
			
			ArrayList<State> adjacentWarriors = new ArrayList<>();
			
			for(int i = 0 ; i < 4 ; i++) { //get all cells adjacent to the current node that have warriors
				if(adjacencyList[Integer.parseInt(currNode.getState().getId())][i] != null
						&& adjacencyList[Integer.parseInt(currNode.getState().getId())][i].getElement().equals("W"))
					adjacentWarriors.add(adjacencyList[Integer.parseInt(currNode.getState().getId())][i]);
			}
			
			for(int i = 0 ; i < gridArray.length ; i++) { //update grid
				for(int j = 0 ; j < gridArray[0].length ; j++) {
					for(int k = 0 ; k < adjacentWarriors.size() ; k++)
						if(gridArray[i][j].getState().equals(adjacentWarriors.get(k)))
							gridArray[i][j].getState().setElement("E");
				}
			}
			
			for(int i = 0 ; i < adjacencyList.length ; i++) { //update adjacency list
				for(int j = 0 ; j < adjacencyList[0].length ; j++) {
					for(int k = 0 ; k < adjacentWarriors.size() ; k++) {
						if(adjacencyList[i][j] != null 
								&&adjacencyList[i][j].getId().equals(adjacentWarriors.get(k)))
							adjacencyList[i][j].setElement("E");
					}
				}
			}
		}
	}
	
	public void updateDamage(Node prevNode, String operator, Node currNode) {
		damage+=this.getStepCost(prevNode.getState(), operator, currNode.getState());
	}
	
//	public LinkedList<Node> updateQueue(LinkedList<Node> queue, Node currNode, String operator){
//		ArrayList<Node> toBeRemoved = new ArrayList<>();
//		
//		if(operator.equals("collect")) {
//			
//			for(int i = 0 ; i < queue.size() ; i++) {
//				if(queue.get(i).getState().equals(currNode.getState())) {
//					queue.get(i).getState().setElement("E");
//					
//					if(queue.get(i).getOperator().equals("collect")) //remove any node from the queue that was supposed to collect the stone that was already collected
//						toBeRemoved.add(queue.get(i));
//				}	
//			}
//		}
//		else if(operator.equals("kill")) {
//			ArrayList<State> adjacentWarriors = new ArrayList<>();
//			
//			ArrayList<State> cellsAdjacentToWarriors = new ArrayList<>();
//			
//			for(int i = 0 ; i < 4 ; i++) { //get all cells adjacent to the current node that have warriors
//				if(adjacencyList[Integer.parseInt(currNode.getState().getId())][i] != null
//						&& adjacencyList[Integer.parseInt(currNode.getState().getId())][i].getElement().equals("W"))
//					adjacentWarriors.add(adjacencyList[Integer.parseInt(currNode.getState().getId())][i]);
//			}
//			
//			for(int i = 0 ; i < queue.size() ; i++) {
//				if(queue.get(i).getState().equals(currNode.getState())) { //remove any node that is in the same state as the current node and has the same operator
//					if(queue.get(i).getOperator().equals("kill"))
//						toBeRemoved.add(queue.get(i));
//				}	
//				
//				for(int j = 0 ; j < adjacentWarriors.size() ; j++) { //remove all warriors from the cells adjacent to the current cell
//					if(queue.get(i).getState().equals(adjacentWarriors.get(j))) { 
//						queue.get(i).getState().setElement("E");
//					}
//				}
//			}
//			
//			for(int i = 0 ; i < adjacentWarriors.size() ; i++) { //get all cells adjacent to warriors
//				for(int j = 0 ; j < 4 ; j++) { 
//					if(adjacencyList[Integer.parseInt(adjacentWarriors.get(i).getId())][j] != null)
//						cellsAdjacentToWarriors.add(adjacencyList[Integer.parseInt(adjacentWarriors.get(i).getId())][j]);
//				}
//			}
//			
//			for(int i = 0 ; i < queue.size() ; i++) {  //remove all nodes in the queue whose cells are adjacent to the killed warriors and have a kill operator
//				for(int j = 0 ; j < cellsAdjacentToWarriors.size() ; j++) {
//					if(queue.get(i).getState().equals(cellsAdjacentToWarriors.get(j))) {
//						if(queue.get(i).getOperator().equals("kill"))
//							toBeRemoved.add(queue.get(i));
//					}
//				}
//			}
//		}
//		
//		for(int i = 0 ; i < toBeRemoved.size() ; i++) {
//			queue.remove(toBeRemoved.get(i));
//		}
//		
//		return queue;
//	}
	
	public boolean nodeVisited(Node prevNode, Node currNode) { //handles repeated states
			
		boolean move = false;
		
		if(!currNode.isRootNode() && !prevNode.isRootNode()) {
			
			if(currNode.getOperator().equals("up") || currNode.getOperator().equals("down") || currNode.getOperator().equals("right") || currNode.getOperator().equals("left"))
					move = true;
			
			if(prevNode.getState().equals(currNode.getState())){
				if(move && currNode.getState().getElement().equals("E")) //iron man moving to an empty cell that was previously visited
					return true;
				else if(prevNode.getOperator().equals("collect")
							&& currNode.getOperator().equals("collect")) //iron man collecting a stone that was already collected
					return true;
				else if(prevNode.getOperator().equals("kill")
							&& currNode.getOperator().equals("kill")) //iron man killing warriors that were already killed
					return true;
					
			}
		}
		return false;
	}
	
	public void visualize(boolean v, Node currNode) {
		if(v) {
			System.out.println("Depth:" + currNode.getDepth() + " ");
			System.out.print("Action:" + currNode.getOperator() + " ");
			System.out.print("Cell:" + currNode.getState().getId() + " ");
			System.out.print("Damage:" + this.damage + " ");
			System.out.print("Stones:" + this.stonesCollected);
			
			System.out.println();

			for(int i = 0 ; i < gridArray.length ; i++) {
				for(int j = 0 ; j < gridArray[0].length ; j++) {
					if(Integer.parseInt(gridArray[i][j].getState().getId()) == ironManArray.get(0))
						System.out.print("I ");
						
					else
						System.out.print(gridArray[i][j].getState().getElement() + " ");
				}
				System.out.println();
			}
			System.out.println();
		}
	}
	
	public EndGame restartGame() {
		return new EndGame(grid);
	}
	
	public int getStonesCollected() {
		return stonesCollected;
	}
	
	public static void main(String[]args) {
		EndGame p = new EndGame("5,5;1,2;3,1;0,2,1,1,2,1,2,2,4,0,4,1;0,3,3,0,3,2,3,4,4,3");
		
//		p.updateGridAndAdjacencyList(p.gridArray[1][3], "kill");
		
//		State nextState = p.getNextState((State) p.gridArray[0][0].getState(), "left");
			
//		System.out.print(nextState);
//		ArrayList<String> operations = p.getOperations((State)p.gridArray[0][2].getState());
		
		for(int i = 0 ; i < p.initialGridArray.length ; i++) {
			for(int j = 0 ; j < p.initialGridArray[0].length ; j++) {
				if(p.initialGridArray[i][j] == null)
					System.out.print("null ");
				else
					System.out.print(p.initialGridArray[i][j].getState().getElement() + " ");
			}
			System.out.println();
			
		}
	
	}
	
	
}
