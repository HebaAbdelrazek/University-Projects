import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  daysLeft: any[];
  username: String = "khadija";
  myNotifications: any[];
  borrowedBooksNotifications: any[];

  constructor(private bookService : BookService) { }

  ngOnInit() {
    this.bookService.getNotifications()
    .subscribe(
      (data) => {
        this.myNotifications = data.data;

       // console.log(this.myBooks); 

      },
      (error) => console.log(error)
    );

    this.bookService.getNotificationsBorrowedBooks()
    .subscribe(
      (data) => {
        this.borrowedBooksNotifications = data.data;

       // console.log(this.myBooks); 

      },
      (error) => console.log(error)
    );


  }

}
