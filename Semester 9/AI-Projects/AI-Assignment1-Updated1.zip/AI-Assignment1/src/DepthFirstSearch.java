import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

public class DepthFirstSearch extends AbstractSearch{

	public ArrayList<Node> depthFirstSearch(LinkedList<Node> queue, EndGame problem) {
		
		done = false;
		while(!done) {
			if(queue.isEmpty()) { //return failure if the queue is empty
				System.out.println("FAILURE 1: there is no solution to this problem");
				done = true;
			}
			else { //if the queue is not empty, remove the node according to the search algorithm used
				Node currNode = queue.remove(queue.size()-1); //remove node from the end of the queue
				
				
//				boolean visitedFlag = false;
//				for(int j = 0 ; j < visited.size() ; j++)
//					if(problem.nodeVisited(visited.get(j), currNode))
//						visitedFlag = true;
//				
//				if(!visitedFlag && currNode.getPathCost() < 100) 
//					visited.add(currNode); //add removed node to the visited queue
//				
				
//				if(!currNode.isRootNode()) { //if the node is not the initial state, update the problem's grid, adjacency list and iron man's damage
//					String operator = currNode.getOperator();
//					
////					problem.updateGridAndAdjacencyList(currNode, operator);
////					problem.updateDamage(currNode.getParent(), operator, currNode);
////				//	this.queue = problem.updateQueue(this.queue, currNode, operator);
////					problem.updateIronManPosition(currNode, operator);
////					problem.updateStonesArray(currNode, operator);
//				}
				
				if(!currNode.isRootNode()) { //if the node is not the initial state, update the problem's grid, adjacency list and iron man's damage
					String operator = currNode.getOperator();
					
					currNode.getEndGame().updateGridAndAdjacencyList(currNode, operator);
					currNode.getEndGame().updateDamage(currNode.getParent(), operator, currNode);
//			//		this.queue = problem.updateQueue(this.queue, currNode, operator);
					currNode.getEndGame().updateIronManPosition(currNode, operator);
					currNode.getEndGame().updateStonesArray(currNode, operator);
				}
				
				plan.add(currNode);
						
				problem.visualize(visualize, currNode); //visualize grid
				
				if(problem.isGoal(currNode)) { //apply the goal test and return the node if the test succeeds
					System.out.println("SUCCESS: goal reached");
					solution = currNode.getPathFromRoot();
//					solution.add(""+problem.damage);
					done = true;
				}
				else { //if it fails the goal test, expand the node further
					ArrayList<Node> expandedNodes = this.expand(currNode, currNode.getEndGame());
					
					for(int i = 0 ; i < expandedNodes.size() ; i++) {	
						queue.add(expandedNodes.get(i)); //add expanded nodes to the queue
					}
				}
				
			}
		}
		
		return solution;
	}

}
