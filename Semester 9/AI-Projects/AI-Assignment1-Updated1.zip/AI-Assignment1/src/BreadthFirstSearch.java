import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

public class BreadthFirstSearch extends AbstractSearch{

	public ArrayList<Node> breadthFirstSearch(LinkedList<Node> queue, EndGame problem) {
		
		done = false;
		while(!done) {
			if(queue.isEmpty()) { //return failure if the queue is empty
				System.out.println("FAILURE 1: there is no solution to this problem");
				done = true;
			}
			else { //if the queue is not empty, remove the node according to the search algorithm used
				Node currNode = queue.remove(0); //remove node from the front of the queue
				
				if(!currNode.isRootNode()) { //if the node is not the initial state, update the problem's grid, adjacency list and iron man's damage
					String operator = currNode.getOperator();
					
					currNode.getEndGame().updateGridAndAdjacencyList(currNode, operator);
					currNode.getEndGame().updateDamage(currNode.getParent(), operator, currNode);
//			//		this.queue = problem.updateQueue(this.queue, currNode, operator);
					currNode.getEndGame().updateIronManPosition(currNode, operator);
					currNode.getEndGame().updateStonesArray(currNode, operator);
				}
								
				//plan.add(currNode);
				
//				problem.visualize(visualize, currNode); //visualize grid
				
				if(currNode.getEndGame().isGoal(currNode)) { //apply the goal test and return the node if the test succeeds
					System.out.println("SUCCESS: goal reached");
					
					ArrayList<Node> planTemp = new ArrayList<>();
					planTemp.add(currNode);
					System.out.println("Goalnode operator " +currNode.getOperator());
					
					Node currNodeTemp = currNode;
					System.out.println(currNodeTemp.getDepth());
					
					for(int i = 0; i < currNodeTemp.getDepth(); i++) {
						System.out.println(currNode.getParent().getOperator());
						planTemp.add(currNode.getParent());
						currNode = currNode.getParent();
					}
					int sizeTemp = planTemp.size();
					for(int i = 0; i< sizeTemp; i++) {
						plan.add(planTemp.remove(planTemp.size()-1));
					}
					solution = plan;
					done = true;
				}
				else { //if it fails the goal test, expand the node further
					ArrayList<Node> expandedNodes = this.expand(currNode, currNode.getEndGame());
					
					for(int i = 0 ; i < expandedNodes.size() ; i++) {	
						queue.add(expandedNodes.get(i)); //add expanded nodes to the queue
					}
				}
				
			}
		}
		
		return solution;
	}

}
