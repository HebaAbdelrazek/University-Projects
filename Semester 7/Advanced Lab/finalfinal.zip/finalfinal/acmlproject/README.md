Help Yourshelf


Our app in a nut-shelf-:

The admin registers and logs in, then he/she gets the books (via Get Books) from the API to our database, so that the user can display them. Then the admin logs out.
2.The admin is able to add new books (via. My Profile).

3.The user registers then logs in, displays the books (via Display Books), if the user borrows any of the books, he/she could check them out in his/her profile (via My Profile) along with their returnal date.

4.The user can receive notifications about new books the admin posts (via Notifications), where he/she will also be notified about money he/she has to pay incase of a book passing its returnal date.

Our app uses an API provided by IT Bookstore, which provides us with access to some of the books in the bookstore's database. Our app also uses MongoDB as its own database, saving the users and books requested through the API with all their information.

Our dependency declaration and isolation tool is npm for node js
we run in the development mode using npm install and npm start, where npm install builds our project and npm start connects our app to mongodb and runs the app on localhost:4200

in the docker, "docker-compose up" builds and runs the mongo image


