import java.util.ArrayList;
import java.util.LinkedList;

public class AStarSearch extends AbstractSearch{
	
	public ArrayList<Node> aStarSearch(LinkedList<Node> queue, EndGame problem){
		done = false;
		while(!done) {
			if(queue.isEmpty()) { //return failure if the queue is empty
				System.out.println("FAILURE 1: there is no solution to this problem");
				done = true;
			}
			else { //if the queue is not empty, remove the node according to the search algorithm used
				for (int i = 0; i < queue.size()-1; i++) //sort nodes from lowest path cost to highest          
				    for (int j = 0; j < queue.size()-i-1; j++)  
				        if ((queue.get(j).getHeuristic()+queue.get(j).getPathCost()) > (queue.get(j+1).getHeuristic()+queue.get(j+1).getPathCost())) {
				        		Node tmp = queue.get(j);
				        		queue.set(j, queue.get(j+1));
				        		queue.set(j+1, tmp);
				        }
				
				for(int i = 0 ; i < queue.size() ; i++)
					System.out.print(queue.get(i).getHeuristic()+queue.get(i).getPathCost() + " ");
				
				Node currNode = queue.remove(0); //remove node with the lowest cost
				
				System.out.println("taken node: " + currNode.getHeuristic());
				
				if(!currNode.isRootNode()) { //if the node is not the initial state, update the problem's grid, adjacency list and iron man's damage
					String operator = currNode.getOperator();
					
//					problem.updateGridAndAdjacencyList(currNode, operator); //updating the grid and the adjacency list
//					problem.updateDamage(currNode.getParent(), operator, currNode); //updating iron man's damage
//					this.queue = problem.updateQueue(this.queue, currNode, operator); //updating the queue
//					problem.updateIronManPosition(currNode, operator); //updating iron man's position
//					problem.updateStonesArray(currNode, operator);
				}
								
				plan.add(currNode);
				
				problem.visualize(visualize, currNode); //visualize grid
				
				if(problem.isGoal(currNode)) { //apply the goal test and return the node if the test succeeds
					System.out.println("SUCCESS: goal reached");
					solution = plan;
					done = true;
				}
				else { //if it fails the goal test, expand the node further
					ArrayList<Node> expandedNodes = this.expand(currNode, problem);
					
					for(int i = 0 ; i < expandedNodes.size() ; i++) {	
						expandedNodes.get(i).setHeuristic(heuristic, problem);
						queue.add(expandedNodes.get(i)); //add expanded nodes to the queue
					}
				}
				
			}
		}
		
		return solution;
	}
}
