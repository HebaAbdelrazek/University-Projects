//var encrypt = require('../utils/Encryption.js'),
   var mongoose = require('mongoose');
    //passportLocalMongoose = require('passport-local-mongoose');

//require('mongoose-type-email');


var userSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    username: {
      type: String,
      required: true,
      unique: true
    },
    password: {
        type: String,
        required: true
    },
    type: {
        type: String,
        enum: ['admin', 'regular_user'],
        default: 'regular_user'
      },
    borrowedBooks: {
        type: [[String]]
    }
    
});

//userSchema.set('autoIndex',false);
//userSchema.plugin(passportLocalMongoose);

module.exports = mongoose.model('User', userSchema);
