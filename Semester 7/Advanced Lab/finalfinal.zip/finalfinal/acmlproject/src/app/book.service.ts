import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Response } from '@angular/http';
import 'rxjs/Rx';
@Injectable()
export class BookService {
    result: any;
    currentUser: String;
    
    constructor(private http : Http, private _http : HttpClient){
       
    }

    getCurrentUser(username: String){
        this.currentUser = username;
       // console.log(this.currentUser);
    }

    returnCurrentUser(){
        return this.currentUser;
    }

    getUsers(){
        return this._http.get("http://localhost:3000/api/getUsers")
        .map(
            result => this.result = result
          );
      }

      getNotifications(){
        return this.http.get("http://localhost:3000/api/getNotifications")
        .map(
            (r: Response) => {
                const data = r.json();
                console.log(data);
                return data;
            }
        );
      }

      getNotificationsBorrowedBooks(){
        return this.http.get("http://localhost:3000/api/getNotificationsBorrowedBooks" + this.currentUser)
        .map(
            (r: Response) => {
                const data = r.json();
                console.log(data);
                return data;
            }
        );
      }

      getBorrowedBooks(){
        return this.http.get("http://localhost:3000/api/getBorrowedBooks" + this.currentUser)
        .map(
            (r: Response) => {
                const data = r.json();
                console.log(data);
                return data;
            }
        );
      }

      getUser(username: String){
        return this.http.get("http://localhost:3000/api/getUser" + username)
        .map(
            (r: Response) => {
                const data = r.json();
                return data;
            }
        );
      }

      getBook(isbn: String){
        return this.http.get("http://localhost:3000/api/getBook" + isbn)
        .map(
            (r: Response) => {
                const data = r.json();
                return data;
            }
        );
      }

    getBooks(){
        return this.http.get('https://api.itbook.store/1.0/search/mongodb.json')
        .map(
            (r: Response) => {
                const data = r.json();
                // for(const book of data){
                //     book.name 
                // }
                return data;
            }
        );
    }

    displayBooks(){
        return this.http.get("http://localhost:3000/api/getBooks")
        .map(
            (r: Response) => {
                const data = r.json();
                return data;
            }
        );
    }

    registerUser(_name: String, _username: String, _password: String, _type: String){
    
       
        const user = {
            name : _name,
            username : _username,
            password : _password,
            type: _type,
            borrowedBooks: []
        };
        
        var i = 0;
       
            return this._http.post("http://localhost:3000/api/registerUser", user)
            .subscribe(response => console.log(response));
        
    }
    
    checkUsername(username: String){
        return this.http.get("http://localhost:3000/api/getUser" + username)
        .map(
            (r: Response) => {
                const data = r.json();
                return data;
            }
        );
    }

    registerBook(title: String, cover: String, description: String, isbn: String, copies: Number){
        
           
        const b = {
            title: title,
            cover: cover,
            description: description,
            isbn: isbn,
            copies: 3
          }
            
           
         return this._http.post("http://localhost:3000/api/registerBook", b)
                .subscribe(response => console.log(response));
            
        }

        updateCopies(update, isbn: String){

                // var config = {
                //     headers:
                //     {
                //         'Content-Type':'application/json',
                //     }
                // }

            console.log("hi");
            return this._http.put("http://localhost:3000/api/updateCopies" + isbn, update)
            .map(
                result => this.result = result
            );
          }

        addBorrowedBooks(update){

            console.log(update);
       
            return this._http.put("http://localhost:3000/api/addBorrowedBooks" + this.currentUser, update)
            .subscribe(response => console.log(response));
      }

      notifyUsersWithNewBook(title: String){
        console.log("blah");
           
        const n = {
            date: new Date(),
            msg: "A new book, " + title + " has been added to the library! Go check it out!",
            receiver:'all_users'
        }
            
           
                return this._http.post("http://localhost:3000/api/notifyUsersWithNewBook", n)
                .subscribe(response => console.log(response));
            
        }


        notifyUserDeadline(title: String){
            console.log("bla");
               
            const n = {
                date: new Date(),
                msg: "You have 1 day left to return ' " + title + "' !",
                receiver: this.currentUser
            }
                
               
                    return this._http.post("http://localhost:3000/api/notifyUserDeadline", n)
                    .subscribe(response => console.log(response));
                
            }

            notifyUserMoney(money: String, title: String){
                console.log("bla");
                   
                const n = {
                    date: new Date(),
                    msg: "You have to pay " + money + " for exceeding the return date of '" + title + "'",
                    receiver: this.currentUser
                }
                    
                   
                        return this._http.post("http://localhost:3000/api/notifyUserMoney", n)
                        .subscribe(response => console.log(response));
                    
                }
    

    

}