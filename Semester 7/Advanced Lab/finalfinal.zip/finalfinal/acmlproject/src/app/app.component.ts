import { Component } from '@angular/core';
import { Response } from '@angular/http';
import { BookService } from './book.service';
import { BooksComponent } from './books/books.component';
import { FormGroup,FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';
  getBooks: boolean = false;
  viewProfile: boolean = false;
  viewHomepage: boolean = true;
  viewRegister: boolean = false;
  viewLogin: boolean = false;
  viewNotifications: boolean = false;
  viewProfileAndBooks: boolean = false;
  userIsRegular: boolean = false;
  registerForm: FormGroup;
  loginForm: FormGroup;
  currentUser: any[];
  userLoggingIn: any[];
  userRegistering: any[];
  currentUserType: String = "regular_user";

  constructor(private bookService : BookService, 
  private bookComponent : BooksComponent){
    this.registerForm = new FormGroup({
      name: new FormControl(),
      username: new FormControl(),
      password: new FormControl(),
      type: new FormControl()
   });

   this.loginForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl()
 });



  }

  onAdminGetBooks(){
    this.bookComponent.adminGetBooks();
   }

   onRegister(){
     if((this.registerForm.value.username != null) 
    && (this.registerForm.value.password != null)
    && this.registerForm.value.name != null
    && this.registerForm.value.type != null){
      this.bookService.checkUsername(this.registerForm.value.username)
      .subscribe(
        (data) => {
          this.userRegistering = data.data;
          console.log(this.userRegistering);
          
          if(this.userRegistering.length == 0 && (this.registerForm.value.password != null) 
        && (this.registerForm.value.username != null) && (this.registerForm.value.name != null)){

            if(this.registerForm.value.type == "admin"){
              this.userIsRegular=false;
              this.currentUserType = "admin";
            }
            else{
              this.userIsRegular=true;
              this.currentUserType = "regular_user";
            }
            this.viewProfileAndBooks = false;
            this.viewLogin = true;
            this.viewRegister = false;
            this.currentUser = this.registerForm.value.username;
            this.bookService.registerUser(this.registerForm.value.name, this.registerForm.value.username, this.registerForm.value.password, this.registerForm.value.type);
        }
          else{
            alert("This username was already taken");
          }
        }
        ,
        (error) => console.log(error)
        ); 
     }
     else{
      alert("You must fill in all the requirements");
    }
    
   }

   onLogin(){
    this.bookService.checkUsername(this.loginForm.value.username)
    .subscribe(
      (data) => {
        this.userLoggingIn = data.data;
        this.currentUserType = this.userLoggingIn[0].type;
        
        if((this.userLoggingIn != null) && this.userLoggingIn[0].password == this.loginForm.value.password){
          

          console.log("type naw: "+this.currentUserType);
          if(this.currentUserType=="admin"){
            this.userIsRegular=false;
          }
          else if(this.currentUserType=="regular_user"){
            this.userIsRegular=true;
          }
          this.viewProfileAndBooks = true;
          this.viewLogin = false;
          this.currentUser = this.userLoggingIn;
        }
        else{
          alert("Wrong username or password");
        }
      }
      ,
      (error) => console.log(error)
      );

   }
   onLogOut(){
    this.viewProfileAndBooks=false;
    this.viewNotifications=false;
   }

   onGetBooks(){
     console.log(this.currentUser[0].username);
     this.bookService.getCurrentUser(this.currentUser[0].username);
   }

   onGetProfile(){
    console.log(this.currentUser[0].username);
    this.bookService.getCurrentUser(this.currentUser[0].username);
  }

  onGetNotifications(){
    console.log(this.currentUser[0].username);
    this.bookService.getCurrentUser(this.currentUser[0].username);
  }
  
      




}
