#include "TextureBuilder.h"
#include "Model_3DS.h"
#include "GLTexture.h"
#include <glut.h>
#include <math.h>
#include <stdio.h> 
#include <random>

#define DEG2RAD(a) (a * 0.0174532925)

double robinY = 0;

bool tedGotRobin = false;
bool barneyDead = false;
bool barneyFront = true;
bool shootBoots = false;
bool shootBook = false;
bool tedDead = false;
double barneyZ = 0;
double barneyX = 0;

double bookX = 0;
double bookZ = 0;

double bootsX = 0;
double bootsY = 0;
double bootsZ = 0;
double rotateBoots = 0;

bool firstPerson = false;

bool level1 = true;
//bool dog1Left = true;
//double dog1X = 0;
int barneyvariable = 0;
bool dog1Finish = false;
bool dog2Finish = false;
bool dog3Finish = false;

int WIDTH = 1280;
int HEIGHT = 720;
//ted COORDS
double tedX = 0;
double tedY = 0;
double tedZ = 0;
double OrgtedX = 10;
double OrgtedY = 0;
double OrgtedZ = 78;
double rotateTed = 0;

double currentCenterX = 0;
double currentCenterY = 0;
double currentCenterZ = 0;

GLuint tex;
GLuint tex_sky;
char title[] = "3D Model Loader Sample";
int score = 0;
int health = 50;
int barneyHealth = 50;

bool horn1Taken = false;
bool horn2Taken = false;
bool horn3Taken = false;
bool horn4Taken = false;
bool hornTaken2 = false;
bool beerTaken2 = false;

bool beer1Taken = false;
bool beer2Taken = false;

bool girl1Finish = false;
bool girl2Finish = false;
float c1 = 0;
float c2 = 0;
float c3 = 0;
// 3D Projection Options
GLdouble fovy = 45.0;
GLdouble aspectRatio = (GLdouble)WIDTH / (GLdouble)HEIGHT;
GLdouble zNear = 0.1;
GLdouble zFar = 900;

class Vector
{
public:
	GLdouble x, y, z;
	Vector() {}
	Vector(GLdouble _x, GLdouble _y, GLdouble _z) : x(_x), y(_y), z(_z) {}
	//================================================================================================//
	// Operator Overloading; In C++ you can override the behavior of operators for you class objects. //
	// Here we are overloading the += operator to add a given value to all vector coordinates.        //
	//================================================================================================//
	void operator +=(float value)
	{
		x += value;
		y += value;
		z += value;
	}
};

Vector Eye(10, 5, 20);
Vector At(11, 0, 0);
Vector Up(0, 1, 0);

int cameraZoom = 0;

// Model Variables
Model_3DS model_house;
Model_3DS model_tree;
Model_3DS model_ted;
Model_3DS model_girl1;
Model_3DS model_bar_rack;
Model_3DS model_horn;
Model_3DS model_dog;
Model_3DS model_beer;
Model_3DS model_robin;
Model_3DS model_lamp;
Model_3DS model_barney;
Model_3DS model_boots;
Model_3DS model_book;

// Textures
GLTexture tex_ground;
GLTexture tex_road;
GLTexture tex_ted;
GLTexture tex_lamp;
GLTexture tex_book;
//GLTexture tex_book;
GLTexture tex_red_glitter;

//=======================================================================
// Lighting Configuration Function
//=======================================================================
//CLASS VECTOR

void drawBarney(double x, double y, double z){
	glTranslated(x, y, z);
	glScaled(0.01, 0.01, 0.01);
	model_barney.Draw();
}

void drawBoots(double x, double y, double z){
	glBindTexture(GL_TEXTURE_2D, tex_red_glitter.texture[0]);
	glTranslated(x + bootsX, y + bootsY, z + bootsZ);
	glRotated(rotateBoots, 0, 1, 0);
	glRotated(90, 1, 0, 0);
	glScaled(0.09, 0.09, 0.09);
	model_boots.Draw();
}
void print(int x, int y, char *string){
	int len, i;

	glRasterPos2f(x, y);
	len = (int)strlen(string);

	for (i = 0; i < len; i++){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, string[i]);
	}
}

void printWin(){
	glColor3f(0.0f, 0.0f, 0.0f);
	print(10, 25, "TED WON ROBIN'S HEART");
}

void printScore(){
	if (level1){
		glColor3f(0.0f, 0.0f, 0.0f);
		print(40, 0, "Score: ");
		char* p0s[20];
		sprintf((char *)p0s, "%d", score);
		print(50, 0, (char *)p0s);
	}
	else{
		glColor3f(0.0f, 0.0f, 0.0f);
		print(5, 25, "Score: ");
		char* p0s[20];
		sprintf((char *)p0s, "%d", score);
		print(20, 25, (char *)p0s);
	}
	
}

void printHealth(){
	glColor3f(0.0f, 0.0f, 0.0f);

	if (level1){
		print(-30, 0, "Health: ");
		char* p0s[20];
		sprintf((char *)p0s, "%d", health);
		print(-20, 0, (char *)p0s);
	}
	else{
		print(5, 20, "Ted Health: ");
		char* p0s[20];
		sprintf((char *)p0s, "%d", health);
		print(20, 20, (char *)p0s);

		print(5, 30, "Barney Health: ");
		sprintf((char *)p0s, "%d", barneyHealth);
		print(20, 30, (char *)p0s);
	}
	
}
void printGameOver(){
	glColor3f(0.0f, 0.0f, 0.0f);
	print(5, 0, "GAME OVER ");
}

class Vector3f {
public:
	float x, y, z;

	Vector3f(float _x = 0.0f, float _y = 0.0f, float _z = 0.0f) {
		x = _x;
		y = _y;
		z = _z;
	}

	Vector3f operator+(Vector3f v) {
		return Vector3f(x + v.x, y + v.y, z + v.z);
	}

	Vector3f operator-(Vector3f v) {
		return Vector3f(x - v.x, y - v.y, z - v.z);
	}

	Vector3f operator*(float n) {
		return Vector3f(x * n, y * n, z * n);
	}

	Vector3f operator/(float n) {
		return Vector3f(x / n, y / n, z / n);
	}

	Vector3f unit() {
		return *this / sqrt(x * x + y * y + z * z);
	}

	Vector3f cross(Vector3f v) {
		return Vector3f(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x);
	}
};
//------------------
//CAMERA CLASS
class Camera {
public:
	Vector3f eye, center, up;

	Camera(float eyeX = 10, float eyeY = 10, float eyeZ =90, float centerX = 11, float centerY = -15, float centerZ = 0, float upX = 0.0f, float upY = 1.0f, float upZ = 0.0f) {
		eye = Vector3f(eyeX, eyeY, eyeZ);
		center = Vector3f(centerX, centerY, centerZ);
		up = Vector3f(upX, upY, upZ);
	}

	void resetCamera(){
		eye = Vector3f(10, 10, 90);
		center = Vector3f(11, -15, 0);
		up = Vector3f(0, 1, 0);
	}

	void setEyeX(float d){
		eye.x += d;
	}

	void setEyeY(float d){
		eye.y += d;
	}

	void setEyeZ(float d){
		eye.z += d;
	}

	void setCenterX(float d){
		center.x += d;
	}

	void setCenterY(float d){
		center.y += d;
	}

	void setCenterZ(float d){
		center.z += d;
	}

	double getCurrentCenterX(){
		return center.x;
	}

	double getCurrentCenterY(){
		return center.y;
	}

	double getCurrentCenterZ(){
		return center.z;
	}

	void pickCenter(double x, double y, double z){
		center.x = x;
		center.y = y;
		center.z = z;
	}

	void moveX(float d) {
		Vector3f right = up.cross(center - eye).unit();
		eye = eye + right * d;
		center = center + right * d;
	}

	void moveY(float d) {
		eye = eye + up.unit() * d;
		center = center + up.unit() * d;
	}

	void moveZ(float d) {
		Vector3f view = (center - eye).unit();
		eye = eye + view * d;
		center = center + view * d;
	}

	void rotateX(float a) {
		Vector3f view = (center - eye).unit();
		Vector3f right = up.cross(view).unit();
		view = view * cos(DEG2RAD(a)) + up * sin(DEG2RAD(a));
		up = view.cross(right);
		center = eye + view;
	}

	void rotateY(float a) {
		Vector3f view = (center - eye).unit();
		Vector3f right = up.cross(view).unit();
		view = view * cos(DEG2RAD(a)) + right * sin(DEG2RAD(a));
		right = view.cross(up);
		center = eye + view;
	}

	void look() {
		gluLookAt(
			eye.x, eye.y, eye.z,
			center.x, center.y, center.z,
			up.x, up.y, up.z
			);
	}
};

Camera camera;
//SETUP CAMERA
void setupCamera() {
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 1280 / 720, 0.1, 500);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	camera.look();
}
//----------------------
//void InitLightSource()
//{
//	// Enable Lighting for this OpenGL Program
//	glEnable(GL_LIGHTING);
//
//	// Enable Light Source number 0
//	// OpengL has 8 light sources
//	glEnable(GL_LIGHT0);
//
//	// Define Light source 0 ambient light
//	GLfloat ambient[] = { 0.1f, 0.1f, 0.1, 1.0f };
//	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
//
//	// Define Light source 0 diffuse light
//	GLfloat diffuse[] = { 0.5f, 0.5f, 0.5f, 1.0f };
//	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
//
//	// Define Light source 0 Specular light
//	GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
//	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
//
//	// Finally, define light source 0 position in World Space
//	GLfloat light_position[] = { 0.0f, 10.0f, 0.0f, 1.0f };
//	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
//	GLfloat light_direction[] = {-1.0,0.0,0.0};
//	glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light_direction);
//}
void setupLights(){
	// Enable Lighting for this OpenGL Program
	glEnable(GL_LIGHTING);

	if (level1){
		GLfloat lmodel_ambient[] = { 0.1f, 0.1f, 0.1f, 1.0f };
		glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);

		// Enable Light Source number 0
		// OpengL has 8 light sources
		glEnable(GL_LIGHT0);
		glEnable(GL_LIGHT2);

		// Define Light source 0 ambient light
		GLfloat ambient[] = { 0, 0, 0, 1.0f };

		// Define Light source 0 diffuse light
		GLfloat diffuse[] = { c1, c2, c3, 1.0f };
		GLfloat diffuse2[] = { 0.2f, 0.1f, 0.8f, 1.0f };

		// Define Light source 0 Specular light
		GLfloat specular[] = { 1.0f, 1.0f, 0.0f, 1.0f };

		// Finally, define light source 0 position in World Space
		GLfloat light_position[] = { 6.75, 3, 78, true };
		GLfloat light_direction[] = { 1.0, 0.0, 0 };
		GLfloat lightIntensity[] = { 100, 100, 100, 1.0f };
		glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 90.0);
		glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light_direction);
		glLightfv(GL_LIGHT0, GL_SPECULAR, lightIntensity);
		GLfloat light_position3[] = { 13, 3, 78, true };
		GLfloat light_direction3[] = { -1.0, 0.0, 0 };
		GLfloat lightIntensity3[] = { 100, 100, 100, 1.0f };
		glLightfv(GL_LIGHT2, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT2, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT2, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT2, GL_POSITION, light_position3);
		glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 90.0);
		glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, light_direction3);
		glLightfv(GL_LIGHT2, GL_SPECULAR, lightIntensity3);
		glEnable(GL_LIGHT1);

		GLfloat light_position2[] = { 10 + tedX, 15, 78 + tedZ , true };
		GLfloat light_direction2[] = { 0.0, -1.0, 0 };
		GLfloat lightIntensity2[] = { 100, 100, 100, 1.0f };
		glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse2);
		glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT1, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT1, GL_POSITION, light_position2);
		glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 90.0);
		glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, light_direction2);
		glLightfv(GL_LIGHT1, GL_SPECULAR, lightIntensity2);





	}
	else{
		/*glPushMatrix();
		drawLamp(15, 7, 78);
		glPopMatrix();

		glPushMatrix();
		drawLamp(15, 7, 48);
		glPopMatrix();

		glPushMatrix();
		drawLamp(15, 7, 18);
		glPopMatrix();

		glPushMatrix();
		drawLamp(15, 7, -12);
		glPopMatrix();

		glPushMatrix();
		drawLamp(3, 7, 78);
		glPopMatrix();

		glPushMatrix();
		drawLamp(3, 7, 48);
		glPopMatrix();

		glPushMatrix();
		drawLamp(3, 7, 18);
		glPopMatrix();

		glPushMatrix();
		drawLamp(3, 7, -12);
		glPopMatrix();*/

		GLfloat ambient[] = { 0, 0, 0, 1.0f };

		// Define Light source 0 diffuse light
		GLfloat diffuse[] = { 1.0f, 1.0f, 0.0f, 1.0f };
		GLfloat diffuseTed[] = { 0.3f, 0.8f, 0.7f, 1.0f };

		// Define Light source 0 Specular light
		GLfloat specular[] = { 1.0f, 1.0f, 0.0f, 1.0f };
		GLfloat light_position0[] = { 35.0 , 7.0, 78 + tedZ  , true };
		GLfloat light_direction0[] = { -1.0, 0.0, 0 };
		glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseTed);
		glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position0);
		glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light_direction0);


		GLfloat light_position1[] = { 35.0 , 7.0 , 78.0 + tedZ * 10, true };
		GLfloat light_direction1[] = { -1.0, 0, 0 };
		glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT1, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT1, GL_POSITION, light_position1);
		glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, light_direction1);

		
		GLfloat light_position2[] = { 35.0 , 7.0  , 78.0 + tedZ * 3 , true };
		GLfloat light_direction2[] = { -1.0, 0, 0 };
		glLightfv(GL_LIGHT2, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT2, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT2, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT2, GL_POSITION, light_position2);
		glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, light_direction2);
		

		GLfloat light_position3[] = { 35.0 , 7.0 , 78.0 + tedZ * 1  , true };
		GLfloat light_direction3[] = { -1.0, 0, 0 };
		glLightfv(GL_LIGHT3, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT3, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT3, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT3, GL_POSITION, light_position3);
		glLightf(GL_LIGHT3, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT3, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, light_direction3);


		GLfloat light_position4[] = { 35.0f, 7.0f, -12.0f, true };
		GLfloat light_direction4[] = { -1.0, 0, 0 };
		glLightfv(GL_LIGHT4, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT4, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT4, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT4, GL_POSITION, light_position4);
		glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT4, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT4, GL_SPOT_DIRECTION, light_direction4);


		GLfloat light_position5[] = { 13.2f, 3.0f, 78.0f, true };
		GLfloat light_direction5[] = { -1.0, 0, 0 };
		glLightfv(GL_LIGHT5, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT5, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT5, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT5, GL_POSITION, light_position5);
		glLightf(GL_LIGHT5, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT5, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT5, GL_SPOT_DIRECTION, light_direction5);


		GLfloat light_position6[] = { 13.2f, 3.0f, 78.0f, true };
		GLfloat light_direction6[] = { -1.0, 0, 0 };
		glLightfv(GL_LIGHT6, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT6, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT6, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT6, GL_POSITION, light_position6);
		glLightf(GL_LIGHT6, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT6, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT6, GL_SPOT_DIRECTION, light_direction6);


		GLfloat light_position7[] = { 13.2f, 3.0f, 78.0f, true };
		GLfloat light_direction7[] = { -1.0, 0, 0 };
		glLightfv(GL_LIGHT7, GL_DIFFUSE, diffuse);
		glLightfv(GL_LIGHT7, GL_AMBIENT, ambient);
		glLightfv(GL_LIGHT7, GL_SPECULAR, specular);
		glLightfv(GL_LIGHT7, GL_POSITION, light_position7);
		glLightf(GL_LIGHT7, GL_SPOT_CUTOFF, 80.0);
		glLightf(GL_LIGHT7, GL_SPOT_EXPONENT, 20.0);
		glLightfv(GL_LIGHT7, GL_SPOT_DIRECTION, light_direction7);
	}
	

}

float RandomFloat(float a, float b){
	float random = ((float)rand()) / ((float)RAND_MAX);
	float diff = b - a;
	float r = random * diff;
	return a + r;
}
//=======================================================================
// Material Configuration Function
//======================================================================
void InitMaterial()
{
	// Enable Material Tracking
	glEnable(GL_COLOR_MATERIAL);

	// Sich will be assigneet Material Properties whd by glColor
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	// Set Material's Specular Color
	// Will be applied to all objects
	GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);

	// Set Material's Shine value (0->128)
	GLfloat shininess[] = { 96.0f };
	glMaterialfv(GL_FRONT, GL_SHININESS, shininess);
}

//=======================================================================
// OpengGL Configuration Function
//=======================================================================
void myInit(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

	gluPerspective(fovy, aspectRatio, zNear, zFar);
	//*******************************************************************************************//
	// fovy:			Angle between the bottom and top of the projectors, in degrees.			 //
	// aspectRatio:		Ratio of width to height of the clipping plane.							 //
	// zNear and zFar:	Specify the front and back clipping planes distances from camera.		 //
	//*******************************************************************************************//

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

	//gluLookAt(Eye.x , Eye.y, Eye.z, At.x , At.y, At.z, Up.x, Up.y, Up.z);
	//*******************************************************************************************//
	// EYE (ex, ey, ez): defines the location of the camera.									 //
	// AT (ax, ay, az):	 denotes the direction where the camera is aiming at.					 //
	// UP (ux, uy, uz):  denotes the upward orientation of the camera.							 //
	//*******************************************************************************************//

	//InitLightSource();

	InitMaterial();

	glEnable(GL_DEPTH_TEST);

	glEnable(GL_NORMALIZE);
}

//=======================================================================
// Render Ground Function
//=======================================================================
void drawTree(double x, double y, double z){
	glPushMatrix();
	glTranslated(x, y, z);
	glScaled(0.8, 1, 0.8);
	model_tree.Draw();
	glPopMatrix();
}

void drawRoadTrees(){
	glPushMatrix();
	drawTree(0, 0, 73);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, 63);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, 53);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, 43);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, 33);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, 23);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, 13);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, -3);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, -13);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, -23);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, -33);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, -43);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, -53);
	glPopMatrix();

	glPushMatrix();
	drawTree(0, 0, -63);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, 73);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, 63);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, 53);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, 43);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, 33);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, 23);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, 13);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, -3);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, -13);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, -23);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, -33);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, -43);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, -53);
	glPopMatrix();

	glPushMatrix();
	drawTree(20, 0, -63);
	glPopMatrix();
}

void RenderGround()
{
	glDisable(GL_LIGHTING);	// Disable lighting 

	glColor3f(0.6, 0.6, 0.6);	// Dim the ground texture a bit

	glEnable(GL_TEXTURE_2D);	// Enable 2D texturing

	if (level1)
		glBindTexture(GL_TEXTURE_2D, tex_ground.texture[0]);	// Bind the ground texture
	else{
		glBindTexture(GL_TEXTURE_2D, tex_road.texture[0]);
	}

	glPushMatrix();
	if (level1){
		glScalef(4.0, 4.0, 4.0);
	}
	else{
		glScalef(2, 2, 4);
	}
	
	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);	// Set quad normal direction.
	glTexCoord2f(0, 0);		// Set tex coordinates ( Using (0,0) -> (5,5) with texture wrapping set to GL_REPEAT to simulate the ground repeated grass texture).
	glVertex3f(-20, 0, -20);
	glTexCoord2f(5, 0);
	glVertex3f(20, 0, -20);
	glTexCoord2f(5, 5);
	glVertex3f(20, 0, 20);
	glTexCoord2f(0, 5);
	glVertex3f(-20, 0, 20);
	glEnd();
	glPopMatrix();

	glEnable(GL_LIGHTING);	// Enable lighting again for other entites coming throung the pipeline.

	glColor3f(1, 1, 1);	// Set material back to white instead of grey used for the ground texture.
}
void renderWall(){
	glDisable(GL_LIGHTING);	// Disable lighting 

	glColor3f(0.6, 0.6, 0.6);	// Dim the ground texture a bit

	glEnable(GL_TEXTURE_2D);	// Enable 2D texturing

	if (level1)
		glBindTexture(GL_TEXTURE_2D, tex_ground.texture[0]);	// Bind the ground texture
	else{
		glBindTexture(GL_TEXTURE_2D, tex_road.texture[0]);
	}

	glPushMatrix();
	glRotated(90, 1, 0, 0);

	if (level1){
		glScalef(4.0, 4.0, 4.0);
	}
	else{
		glScalef(2, 2, 4);
	}

	glBegin(GL_QUADS);
	glNormal3f(0, 1, 0);	// Set quad normal direction.
	glTexCoord2f(0, 0);		// Set tex coordinates ( Using (0,0) -> (5,5) with texture wrapping set to GL_REPEAT to simulate the ground repeated grass texture).
	glVertex3f(-20, 0, -20);
	glTexCoord2f(5, 0);
	glVertex3f(20, 0, -20);
	glTexCoord2f(5, 5);
	glVertex3f(20, 0, 20);
	glTexCoord2f(0, 5);
	glVertex3f(-20, 0, 20);
	glEnd();
	glPopMatrix();

	glEnable(GL_LIGHTING);	// Enable lighting again for other entites coming throung the pipeline.

	glColor3f(1, 1, 1);

}
void DrawTed(double x,double y,double z){
	glTranslatef(10 + x, 0 + y,78+ z);
	glScalef(0.05, 0.05, 0.05);
	glRotated(rotateTed, 0, 1, 0);
	glRotated(-180, 0, 1, 0);
	glRotated(90, 1, 0, 0);
	
	model_ted.Draw();
}

void drawBarRack(double x,double y,double z,double d){
	glPushMatrix();
	glTranslatef(x,1+y,z);
	glRotated(48+d, 0, 1, 0);
	glScalef(0.01, 0.01, 0.01);
	model_bar_rack.Draw();
	glPopMatrix();
}

void drawHorn(double x, double y, double z){
	glTranslated(0 + x, 5 + y, 0 + z);
	glScaled(0.02, 0.02, 0.02);
	glRotated(180, 1, 0, 0);
	model_horn.Draw();
}

void drawDog(double x, double y, double z){
	glTranslated(x, 5 + y, z);
	glScaled(0.02, 0.02, 0.02);
	//glRotated(180, 1, 0, 0);
	model_dog.Draw();
}

void drawGirl1(double x, double y, double z){
	glTranslated(x, 5 + y, z);
	glScaled(0.02, 0.02, 0.02);
	glRotated(90, 1, 0, 0);
	model_girl1.Draw();
}

void drawBeer(double x, double y, double z){
	glTranslated(x, 5.2 + y, z);
	glScaled(0.05, 0.05, 0.05);
	glRotated(90, 1, 0, 0);
	model_beer.Draw();
}



void drawOlive(double x, double y, double z){
	glPushMatrix();

	glPopMatrix();
}
void drawBook(double x, double y, double z){
	glTranslated(x,y, z);
	glScaled(0.1,0.1, 0.07);
	glRotated(90, 0, 1, 0);

	model_book.Draw();
}

void drawMaze(){
	glPushMatrix();
	drawBarRack(6.5, 0, 78, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(6.55, 0, 72.5, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(6.6, 0, 67, 0);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(5, 0, 63, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(4, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(1, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-2, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-5, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-8, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-11, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-14, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-17, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-20, 0, 63, 90);
	glPopMatrix();

	glPopMatrix();
	glPushMatrix();
	drawBarRack(-23.5, 0, 61.3, 0);
	glPopMatrix();



	glPushMatrix();
	drawBarRack(15.35, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(16, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(19, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(22, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(25, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(28, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(31, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(34, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(37, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(42, 0, 63, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(1, 0, 63, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(1, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-2, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(4, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(7, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(10, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(13, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(16, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(19, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(22, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(25, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(28, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(31, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(34, 0, 52, 90);
	glPopMatrix();


	glPushMatrix();
	drawBarRack(37, 0, 50.5, 00);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(38.75, 0, 47, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(40.25, 0, 50.5, 00);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(43, 0, 52, 90);
	glPopMatrix();


	glPushMatrix();
	drawBarRack(48, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(51.65, 0, 63, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(51.65, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(43, 0, 73, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(48, 0, 73, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(49.8, 0, 69, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(49.8, 0, 65, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(53.3, 0, 60, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(53.3, 0, 56, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(43, 0, 68, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(41.33, 0, 70, 0);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(44.7, 0, 64.9, 0);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(-5, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-8, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-11, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-14, 0, 52, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-17.5, 0, 50.2, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-17.5, 0, 45, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-17.5, 0, 40, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-17.5, 0, 35, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-19.15, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-24, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-29, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-34, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-39, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-44, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-49, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-54, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-59, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-64, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-69, 0, 31, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-74, 0, 31, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(-23.5, 0, 56, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-23.5, 0, 51, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-23.5, 0, 46, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-23.5, 0, 41, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-25.1, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-29, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-34, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-39, 0, 37, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(-46.65, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-51, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-56, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-61, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-66, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-71, 0, 37, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-76, 0, 37, 90);
	glPopMatrix();


	glPushMatrix();
	drawBarRack(-40.66, 0, 39, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-45, 0, 39, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-40.66, 0, 44, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-45, 0, 44, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-40.66, 0, 49, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-45, 0, 49, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-40.66, 0, 54, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-42.4, 0, 55.8, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(-47, 0, 50.7, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(-47, 0, 55.8, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-52, 0, 55.8, 90);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(-53.65, 0, 53, 0);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(-52, 0, 50.7, 90);
	glPopMatrix();

	glPushMatrix();
	drawBarRack(13.5, 0, 78, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(13.55, 0, 72.5, 0);
	glPopMatrix();
	glPushMatrix();
	drawBarRack(13.6, 0, 67, 0);
	glPopMatrix();
}

void drawStreetLamp(double x, double y, double z){
	glPushMatrix();
	glTranslated(x, y+7, z);
	glRotated(90, 1, 0, 0);
	GLUquadricObj*qobj;
	qobj = gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluCylinder(qobj, 0.07, 0.07, 8, 8,8);
	glPopMatrix();
}

void drawLamp(double x, double y, double z){
	glTranslated(x, y, z);
	glDisable(GL_LIGHTING);	// Disable lighting 
	glColor3f(0.6, 0.6, 0.6);	// Dim the ground texture a bit
	glEnable(GL_TEXTURE_2D);	// Enable 2D texturing

	glBindTexture(GL_TEXTURE_2D, tex_lamp.texture[0]);	// Bind the ground texture
	glPushMatrix();
	glTexCoord2f(0, 0);		// Set tex coordinates ( Using (0,0) -> (5,5) with texture wrapping set to GL_REPEAT to simulate the ground repeated grass texture).

	glTexCoord2f(5, 0);
	glutSolidSphere(0.4, 100, 100);

	glPopMatrix();






	glEnable(GL_LIGHTING);	// Enable lighting again for other entites coming throung the pipeline.

	glColor3f(1, 1, 1);	// Set material back to white instead of grey used for the ground texture.
}

//=======================================================================
// Display Function
//=======================================================================
void myDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	if (level1){
		setupCamera();
		setupLights();
	//	PlaySound("D:\Lab 7\OpenGLMeshLoader\careless.wav", NULL, SND_ASYNC | SND_FILENAME | SND_LOOP);
		/*GLfloat lightIntensity[] = { 0.3, 0.3, 0.3, 1.0f };
		GLfloat lightPosition[] = { 0.0f, 100.0f, 0.0f, 0.0f };
		glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
		glLightfv(GL_LIGHT0, GL_AMBIENT, lightIntensity);*/

		// Draw Ground
		RenderGround();
		//DRAW TED 
		if (!tedDead){
			glPushMatrix();
			DrawTed(tedX, tedY, tedZ);
			glPopMatrix();
		}
		else{
			printGameOver();
		}

		//DRAW MAZE
		drawMaze();
		//------------------------------------
		//bar wall box
		glPushMatrix();

		GLUquadricObj * qobj;
		qobj = gluNewQuadric();
		glTranslated(50, 0, 0);
		glRotated(90, 1, 0, 1);
		glBindTexture(GL_TEXTURE_2D, tex);
		gluQuadricTexture(qobj, true);
		gluQuadricNormals(qobj, GL_SMOOTH);
		gluSphere(qobj, 400, 100, 100);
		gluDeleteQuadric(qobj);

		glPopMatrix();



		glPushMatrix();
		drawBeer(6.5, -3, 73);
		glPopMatrix();


		glPushMatrix();
		drawBeer(-5, -3, 63);
		glPopMatrix();


		glPushMatrix();
		drawBeer( - 35, -3, 63);
		glPopMatrix();


		glPushMatrix();
		drawBeer(42, -3, 63);
		glPopMatrix();



		glPushMatrix();
		drawBeer(37, -3, 63);
		glPopMatrix();


		glPushMatrix();
		drawBeer(51.65, -3, 52);
		glPopMatrix();


		glPushMatrix();
		drawBeer(-19.15, -3, 31);
		glPopMatrix();



		glPushMatrix();
		drawBeer(34, -3, 52);
		glPopMatrix();



		glPushMatrix();
		drawBeer(1,-3, 63);
		glPopMatrix();

		//horn

		if (!horn1Taken){
			glPushMatrix();
			drawHorn(-60, -4, 34);
			glPopMatrix();
		}

		if (!horn2Taken){
			glPushMatrix();
			drawHorn(22, -4, 58);
			glPopMatrix();
		}

		if (!horn3Taken){
			glPushMatrix();
			drawHorn(-7.5, -4, 59);
			glPopMatrix();
		}

		if (!horn4Taken){
			glPushMatrix();
			drawHorn(-43, -4, 48);
			glPopMatrix();
		}


		//robin
	
		glPushMatrix();
		drawGirl1(-78, -5, 33);
		glPopMatrix();


		//dog

		if (!dog1Finish){
			glPushMatrix();
			drawDog(37, -5, 58);
			glPopMatrix();
		}
		
		if (!dog2Finish){
			glPushMatrix();
			drawDog(-52, -5, 34);
			glPopMatrix();
		}
		
		if (!dog3Finish){
			glPushMatrix();
			drawDog(-20, -5, 45);
			glPopMatrix();
		}
		glPushMatrix();
		drawBeer(14, -5, 70);
		glPopMatrix();

		//beer
		if (!beer1Taken){
			glPushMatrix();
			drawBeer(-21, -5, 52);
			glPopMatrix();
		}

		if (!beer2Taken){
			glPushMatrix();
			drawBeer(-35, -5, 33);
			glPopMatrix();
		}

		//girl obs 1

		if (!girl1Finish){
			glColor3f(0, 0, 0);
			glPushMatrix();
			drawGirl1(-42, -5, 44);
			glPopMatrix();
		}
		
		if (!girl2Finish){
			glColor3f(0, 0, 0);
			glPushMatrix();
			drawGirl1(30, -5, 57);
			glPopMatrix();
		}
		
		glPushMatrix();
		//glColor3f(1, 0, 0);
		drawLamp(6.75,3,78);
		glPopMatrix();

		glPushMatrix();
		//glColor3f(1, 0, 0);
		drawLamp(13.2,3,78);
		glPopMatrix();

		//display health and score
		glPushMatrix();
		glTranslated(tedX, tedY, tedZ);
		printScore();
		printHealth();
		glPopMatrix();

	}
	else {
			setupCamera();

			setupLights();

			/*GLfloat lightIntensity[] = { 0.7, 0.7, 0.7, 1.0f };
			GLfloat lightPosition[] = { 0.0f, 100.0f, 0.0f, 0.0f };
			glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
			glLightfv(GL_LIGHT0, GL_AMBIENT, lightIntensity);*/

			

			// Draw Ground
			RenderGround();

			//DRAW TED 
			if (!tedDead){
				glPushMatrix();
				DrawTed(tedX, tedY, tedZ);
				glPopMatrix();
			}
			//sky box
			glPushMatrix();

			GLUquadricObj * qobj;
			qobj = gluNewQuadric();
			glTranslated(50, 0, 0);
			glRotated(90, 1, 0, 1);
			glBindTexture(GL_TEXTURE_2D, tex_sky);
			gluQuadricTexture(qobj, true);
			gluQuadricNormals(qobj, GL_SMOOTH);
			gluSphere(qobj, 400, 100, 100);
			gluDeleteQuadric(qobj);



			glPopMatrix();
			//book
			if (!barneyDead){
				glPushMatrix();
				drawBook(10, 0, 10 + bookZ);
				glPopMatrix();
			}

			drawRoadTrees();
			if (!barneyDead){
				glPushMatrix();
				drawBarney(10, 0, 10 + barneyZ);
				glPopMatrix();
			}
			if (!tedDead){
				glPushMatrix();
				drawBoots(10, 2, 77);
				glPopMatrix();
			}
			else{
				printGameOver();
			}
			if (!hornTaken2){
				glPushMatrix();
				drawHorn(7, -4, 12);
				glPopMatrix();
			}
			if (!beerTaken2){
				glPushMatrix();
				drawBeer(12, -4, 50);
				glPopMatrix();
			}
			if (barneyDead){
				glPushMatrix();
				drawGirl1(10, -5+robinY, 10);
				glPopMatrix();
			}

			glPushMatrix();
			drawStreetLamp(3, 0, 78);
			glPopMatrix();

			glPushMatrix();
			drawStreetLamp(3, 0, 48);
			glPopMatrix();

			glPushMatrix();
			drawStreetLamp(3, 0, 18);
			glPopMatrix();

			glPushMatrix();
			drawStreetLamp(3, 0, -12);
			glPopMatrix();

			glPushMatrix();
			drawStreetLamp(15, 0, 78);
			glPopMatrix();

			glPushMatrix();
			drawStreetLamp(15, 0, 48);
			glPopMatrix();

			glPushMatrix();
			drawStreetLamp(15, 0, 18);
			glPopMatrix();

			glPushMatrix();
			drawStreetLamp(15, 0, -12);
			glPopMatrix();

			glPushMatrix();
			drawLamp(15, 7, 78);
			glPopMatrix();

			glPushMatrix();
			drawLamp(15, 7, 48);
			glPopMatrix();

			glPushMatrix();
			drawLamp(15, 7, 18);
			glPopMatrix();

			glPushMatrix();
			drawLamp(15, 7, -12);
			glPopMatrix();

			glPushMatrix();
			drawLamp(3, 7, 78);
			glPopMatrix();

			glPushMatrix();
			drawLamp(3, 7, 48);
			glPopMatrix();

			glPushMatrix();
			drawLamp(3, 7, 18);
			glPopMatrix();

			glPushMatrix();
			drawLamp(3, 7, -12);
			glPopMatrix();

			//display health and score
			glPushMatrix();
			glTranslated(tedX, tedY, tedZ);
			printScore();
			printHealth();
			glPopMatrix();

			if (tedGotRobin){
				printWin();
			//	PlaySound("careless.wav", NULL, SND_ASYNC | SND_FILENAME | SND_LOOP);
			}

			}

		
	
	

	glutSwapBuffers();
}

//=======================================================================
// Keyboard Function
//=======================================================================
void myKeyboard(unsigned char button, int x, int y)
{
	switch (button)
	{
	case 'b':
		if (!shootBoots)
			shootBoots = true;
		break;
	case 'w':
		if (firstPerson){
			camera.rotateX(0.7);
		}
		
		break;
	case 's':
		if (firstPerson){
			camera.rotateX(-0.7);
		}
		
		break;
	case 27:
		exit(0);
		break;
	case 'a':
		if (firstPerson){
			camera.rotateY(0.7);
		}
		
		break;
	case 'd':
		if (firstPerson){
			camera.rotateY(-0.7);
		}
		
		break;
	case 'f':
		if (firstPerson == false){
			firstPerson = true;
			currentCenterX = camera.getCurrentCenterX();
			currentCenterY = camera.getCurrentCenterY();
			currentCenterZ = camera.getCurrentCenterZ();
			camera.setEyeZ(-12);
			//camera.setCenterY(7);
			camera.setEyeY(-6);
			//camera.setY(-6);
		}
		else{
			firstPerson = false;
			camera.setEyeZ(12);
			//camera.setCenterY(-7);
			camera.pickCenter(currentCenterX, currentCenterY, currentCenterZ);
			camera.setEyeY(6);
			//camera.setY(6);
		}
		
		break;
	default:
		break;
	}

	glutPostRedisplay();
}
void Special(int key, int x, int y) {

	switch (key) {
	case GLUT_KEY_UP:

		if (level1){
			tedZ -= 0.2;
			camera.setEyeZ(-0.2);
			camera.setCenterZ(-0.2);

			if (firstPerson){
				currentCenterZ -= 0.2;
			}

			rotateTed = 0;
		}
		else{
			tedZ -= 0.2;
			camera.setEyeZ(-0.2);
			camera.setCenterZ(-0.2);
			rotateTed = 0;

			if (firstPerson){
				currentCenterZ -= 0.2;
			}

			if (!shootBoots){
				bootsZ -= 0.2;
				rotateBoots = 0;
			}
			
		}
		
		break;

	case GLUT_KEY_DOWN:
		if (level1){
			tedZ += 0.2;
			camera.setEyeZ(0.2);
			camera.setCenterZ(0.2);
			if (firstPerson){
				currentCenterZ += 0.2;
			}
			rotateTed = 180;
		}
		else{
			tedZ += 0.2;
			camera.setEyeZ(0.2);
			camera.setCenterZ(0.2);
			if (firstPerson){
				currentCenterZ += 0.2;
			}

			rotateTed = 180;
			if (!shootBoots){
				rotateBoots = 180;
				bootsZ += 0.2;
			}
			
		}
		
		break;
	case GLUT_KEY_LEFT:
		if (level1){
			if (((OrgtedX + tedX > 6.5 + 1.5) || (OrgtedZ + tedZ < 62))
				&& ((OrgtedX + tedX > 6.5 - 30 + 1.7) || (OrgtedZ + tedZ < 35))){

				tedX -= 0.2;
				camera.setEyeX(-0.2);
				camera.setCenterX(-0.2);
				rotateTed = 90;

				if (firstPerson){
					currentCenterX -= 0.2;
				}
			}
			if ((OrgtedX + tedX > 6.5 - 51.5 + 1.7) && (OrgtedX + tedX < 6.5 - 50 + 1.7) && ((OrgtedZ + tedZ > 35))){
				tedX -= 0.2;
				camera.setEyeX(-0.2);
				camera.setCenterX(-0.2);
				rotateTed = 90;

				if (firstPerson){
					currentCenterX -= 0.2;
				}
			}
			if ((OrgtedX + tedX < 6.5 - 50 + 1.7) && (OrgtedX + tedX > 6.5 - 60.5 + 1.7) && (OrgtedZ + tedZ > 53)){
				tedX -= 0.2;
				camera.setEyeX(-0.2);
				camera.setCenterX(-0.2);
				rotateTed = 90;

				if (firstPerson){
					currentCenterX -= 0.2;
				}
			}

		}
		else{
			tedX -= 0.2;
			camera.setEyeX(-0.2);
			camera.setCenterX(-0.2);
			rotateTed = 90;
			

			if (firstPerson){
				currentCenterX -= 0.2;
			}

			if (!shootBoots){
				rotateBoots = 90;
				bootsX -= 0.2;
			}
			
		}
		
		
		break;
	case GLUT_KEY_RIGHT:
		if (level1){
			if (((OrgtedX + tedX < 10.5 + 1.5) || (OrgtedZ + tedZ < 62))
				&& ((OrgtedX + tedX < 51.5))){
				tedX += 0.2;
				camera.setEyeX(0.2);
				camera.setCenterX(0.2);
				rotateTed = -90;

				if (firstPerson){
					currentCenterX += 0.2;
				}
			}
			//if ((OrgtedX + tedX < 6.5 - 30 + 1.7) && (OrgtedZ + tedZ > 35)){
			//	tedX += 0.2;
			//	//camera.moveX(0.2);
			//	camera.setX(0.2);
			//	rotateTed = -90;
			//}
		}
		else{
			tedX += 0.2;
			camera.setEyeX(0.2);
			camera.setCenterX(0.2);
			rotateTed = -90;

			if (firstPerson){
				currentCenterX += 0.2;
			}

			if (!shootBoots){
				bootsX += 0.2;
				rotateBoots = -90;
			}
			
		}
		
		break;
	}

	glutPostRedisplay();
}

//=======================================================================
// Motion Function
//=======================================================================
void myMotion(int x, int y)
{
	y = HEIGHT - y;

	if (cameraZoom - y > 0)
	{
		camera.rotateX(-0.1);
		//camera.rotateZ(-0.1);
	}
	else
	{
		camera.rotateX(0.1);
		//camera.rotateZ(0.1);
	}

	cameraZoom = y;

	glLoadIdentity();	//Clear Model_View Matrix

	//gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);	//Setup Camera with modified paramters

	//GLfloat light_position[] = { 0.0f, 10.0f, 0.0f, 1.0f };
	//glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	glutPostRedisplay();	//Re-draw scene 
}

//=======================================================================
// Mouse Function
//=======================================================================
void myMouse(int button, int state, int x, int y)
{
	if (state == GLUT_DOWN)
	{
		shootBoots = true;
	}
}

//=======================================================================
// Reshape Function
//=======================================================================
void myReshape(int w, int h)
{
	if (h == 0) {
		h = 1;
	}

	WIDTH = w;
	HEIGHT = h;

	// set the drawable region of the window
	glViewport(0, 0, w, h);

	// set up the projection matrix 
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fovy, (GLdouble)WIDTH / (GLdouble)HEIGHT, zNear, zFar);

	// go back to modelview matrix so we can move the objects about
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
//	gluLookAt(Eye.x, Eye.y, Eye.z, At.x, At.y, At.z, Up.x, Up.y, Up.z);
}

//=======================================================================
// Assets Loading Function
//=======================================================================
void LoadAssets()
{
	// Loading Model files
	model_house.Load("Models/house/house.3DS");
	model_tree.Load("Models/tree/Tree1.3ds");
	model_dog.Load("Models/Dog/dog.3ds");
	model_bar_rack.Load("Models/table/Table 1.3ds");
	model_ted.Load("Models/ted/ted.3ds");
	model_horn.Load("Models/horn/10382_FrenchHorn_v2_L3.3ds");
	model_girl1.Load("Models/girl1/Belle.3ds");
	model_beer.Load("Models/beer/objBeer.3ds");
	model_barney.Load("Models/barney/Old Asian Business Man.3ds");
	model_boots.Load("Models/red_boots/Army_boots.3ds");
	model_book.Load("Models/book/Sample_Book.3DS");

	// Loading texture files
	tex_ground.Load("Textures/wood_floor.bmp");
	tex_road.Load("Textures/road_texture.bmp");
	tex_lamp.Load("Textures/yellow.bmp");
	//tex_book.load("Textures/images-2.bmp")l
	//tex_sky.Load("Textures/blue-sky-3.bmp");

	loadBMP(&tex_sky, "Textures/blu-sky-3.bmp", true);
	loadBMP(&tex, "Textures/wall_wood.bmp", true);



}	

void anim(){
	

	if (level1){
		c1 = RandomFloat(0, 1);
		c2 = RandomFloat(0.1, 0.9);
		c3 = RandomFloat(0, 0.8);

		if ((tedX + 10 >= -61) && (tedX + 10 <= -59)
			&& (tedY >= -9)
			&& (tedZ + 78 >= 33) && (tedZ + 78 <= 35)){
			if (!horn1Taken)
				score += 10;
			horn1Taken = true;
		}

		if ((tedX + 10 >= 21) && (tedX + 10 <= 23)
			&& (tedY >= -9)
			&& (tedZ + 78 >= 57) && (tedZ + 78 <= 59)
			){
			if (!horn2Taken)
				score += 10;
			horn2Taken = true;
		}

		if ((tedX + 10 >= -8.5) && (tedX + 10 <= -6.5)
			&& (tedY >= -9)
			&& (tedZ + 78 >= 58) && (tedZ + 78 <= 60)
			){
			if (!horn3Taken)
				score += 10;
			horn3Taken = true;
		}

		if ((tedX + 10 >= -44) && (tedX + 10 <= -42)
			&& (tedY >= -9)
			&& (tedZ + 78 >= 47) && (tedZ + 78 <= 49)
			){
			if (!horn4Taken)
				score += 10;
			horn4Taken = true;
		}

		if ((tedX + 10 >= -22) && (tedX + 10 <= -20)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 51) && (tedZ + 78 <= 53)
			){
			if (!beer1Taken)
				health += 10;
			beer1Taken = true;
		}

		if ((tedX + 10 >= -36) && (tedX + 10 <= -34)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 32) && (tedZ + 78 <= 34)
			){
			if (!beer2Taken)
				health += 10;
			beer2Taken = true;
		}

		if ((tedX + 10 >= -79) && (tedX + 10 <= -77)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 32) && (tedZ + 78 <= 34)){
			level1 = false;
			health = 50;
			tedX = 0;
			tedY = 0;
			tedZ = 0;
			camera.resetCamera();
		}

		

		if ((tedX + 10 >= 36) && (tedX + 10 <= 38)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 57) && (tedZ + 78 <= 59)){

			if (!dog1Finish){
				health -= 10;
				if (health <= 0)
					tedDead = true;


			}
			dog1Finish = true;
		}
		if ((tedX + 10 >= -53) && (tedX + 10 <= -51)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 33) && (tedZ + 78 <= 35)){

			if (!dog2Finish){
				health -= 10;
				if (health <= 0)
					tedDead = true;
			}
			dog2Finish = true;
		}

		if ((tedX + 10 >= -21) && (tedX + 10 <= -19)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 44) && (tedZ + 78 <= 46)){

			if (!dog3Finish){
				health -= 10;
				if (health <= 0)
					tedDead = true;
			}
			dog3Finish = true;
		}

		if ((tedX + 10 >= -43) && (tedX + 10 <= -41)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 43) && (tedZ + 78 <= 45)){

			if (!girl1Finish){
				health -= 20;
				if (health <= 0)
					tedDead = true;
			}
			girl1Finish = true;
		}

		if ((tedX + 10 >= 29) && (tedX + 10 <= 31)
			&& (tedY >= -10.5)
			&& (tedZ + 78 >= 56) && (tedZ + 78 <= 58)){

			if (!girl2Finish){
				health -= 20;
				if (health <= 0)
					tedDead = true;
			}
			girl2Finish = true;
		}

	}
	
	if (!level1){
		if (barneyZ >= 0 && barneyFront){
			barneyZ -= 0.1;
			if (!shootBook){
				bookZ -= 0.1;
			}
		}
		else if (barneyFront){
			barneyFront = false;
			barneyZ += 0.1;
			if (!shootBook){
				bookZ += 0.1;
			}
		}
		else if ((barneyZ < 68) && !barneyFront){
			barneyZ += 0.1;
			if (!shootBook){
				bookZ += 0.1;
			}
		}
		else{
			barneyFront = true;
			barneyZ -= 0.1;
			if (!shootBook){
				bookZ += 0.1;
			}
		}
		if (shootBoots && bootsZ > -68){
			bootsZ -= 0.2;
		}
		else if (shootBoots){
			shootBoots = false;
			bootsZ = tedZ;
			bootsX = tedX;
			bootsY = tedY;
		}

		if (shootBook && bookZ < 68){
			bookZ += 0.3;
		}
		else if (shootBook){
			shootBook = false;
			bookZ = barneyZ;

		}

		if (!barneyDead){
			if ((bookX + 10 >= 8 + tedX) && (bookX + 10 <= 12 + tedX)
				&& (bookZ + 10 >= 76 + tedZ) && (bookZ + 10 <= 80 + tedZ)
				){
				if (shootBook){
					health -= 10;
					if (health == 0){
						tedDead = true;
					}
				}
				bookZ = barneyZ;
				shootBook = false;
			}

		}
		
		if ((bootsX + 10 >= 8 + barneyX) && (bootsX + 10 <= 12 + barneyX)
			&& (bootsZ + 78 >= 8 + barneyZ) && (bootsZ + 78 <= 12 + barneyZ)
			){
			if (shootBoots){
				barneyHealth -= 10;
				if (barneyHealth == 0) {
					barneyDead = true;

				}
			}
			bootsZ = tedZ;
			bootsX = tedX;
			shootBoots = false;
		}

		if ((6 >= tedX + 8) && (8 <= tedX + 8) && (11 >= tedZ + 76) && (13 <= tedZ + 76)){
			if (!hornTaken2)
				score += 10;
			hornTaken2 = true;

		}

		if ((tedX + 10 >= 6) && (tedX + 10 <= 8)
			&& (tedY >= -9)
			&& (tedZ + 78 >= 11) && (tedZ + 78 <= 13)){
			if (!hornTaken2)
				score += 10;
			hornTaken2 = true;
		}
		if ((tedX + 10 >= 11) && (tedX + 10 <= 13)
			&& (tedY >= -9)
			&& (tedZ + 78 >= 49) && (tedZ + 78 <= 51)){
			if (!beerTaken2)
				health += 10;
			beerTaken2 = true;
		}
		if (barneyDead && (tedX + 10 >= 9) && (tedX + 10 <= 11) && (tedY >= -9) && (tedZ + 78 >= 9) && (tedZ + 78 <= 11)){
			tedY += 0.1;
			robinY += 0.1;
			tedGotRobin = true;
		}
			drawGirl1(10, -5, 10);
	}

	
	glutPostRedisplay();
}

void shootBookTimer(int value){
	shootBook = true;
	glutTimerFunc(5000, shootBookTimer, 0);
}


//=======================================================================
// Main Function
//=======================================================================
void main(int argc, char** argv)
{
	glutInit(&argc, argv);
	 
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	glutInitWindowSize(WIDTH, HEIGHT);

	glutInitWindowPosition(100, 150);

	glutIdleFunc(anim);

	glutCreateWindow(title);

	glutDisplayFunc(myDisplay);

	glutKeyboardFunc(myKeyboard);

	glutMotionFunc(myMotion);

	glutMouseFunc(myMouse);

	glutTimerFunc(0, shootBookTimer, 0);

	glutReshapeFunc(myReshape);
	glutSpecialFunc(Special);


	//myInit();

	LoadAssets();
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHT2);
	glEnable(GL_LIGHT3);
	glEnable(GL_LIGHT4);
	glEnable(GL_LIGHT5);
	glEnable(GL_LIGHT6);
	glEnable(GL_LIGHT7);

	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);

	glShadeModel(GL_SMOOTH);

	glutMainLoop();
}