var mongoose = require('mongoose'),
moment = require('moment'),
Validations = require('../utils/Validations');
const User = mongoose.model('User');
const addSubtractDate = require("add-subtract-date");
//passport = require('passport');
//notifications = mongoose.model('Notification'),
//nodemailer = require('nodemailer');

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

module.exports.register_user = function (req, res, next){
    
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("acmlproject");
        var user = req.body;
        dbo.collection("users").insertOne(user, function(err, res) {
          if (err) 
            console.log("This username already exists");
          else
            console.log("User registered successfulyy");
          db.close();
        });
      });
  };

  module.exports.getUsers = async (req, res) => {
    //console.log("hoi");
    const users = await User.find().exec();
  
      res.status(200).json({
        err: null,
        msg: 'Users retrieved successfully.',
        data: users
      });
  };

  module.exports.getUserByUsername = async (req, res) => {
    console.log("hoi");
    var userName = req.params.username;
    console.log(userName);
    
    const user = await User.find({"username" : userName}).exec();
  
    if(!user){
        return res.status(404).json({ msg: 'User not found', data: null });
    
      }
      return res.status(200).json({
        err: null,
        msg: 'User retrieved successfully',
        data: user
      });
  };

  module.exports.addBorrowedBooks= async (req, res) => {
    
   // console.log("AAAAAAA");
    
    var username = req.params.username;
    
    var borrowDay = new Date();
    var returnDay = new Date();

    returnDay.setDate(returnDay.getDate() + 1);
    // var returnDay = now.getDay + 3;
    // var returnMonth
    // //console.log(datetime);
    const edited = await User.update(
        {"username" : username},
        {$addToSet:
            {borrowedBooks : [req.body.title,req.body.cover,req.body.subtitle,req.body.isbn,borrowDay,returnDay]}
        }
      ).exec();
      if (!edited) {
        return res
          .status(404)
          .json({ err: null, msg: 'not found.', data: null });
      }
      res.status(200).json({
        err: null,
        msg: 'updated successfully.',
        data: edited
      });
     };

     module.exports.getBorrowedBooks = async (req, res) => {
        //console.log("ahlan");
        
        var username = req.params.username;
        const user = await User.find({"username":username}).exec();
        
          if(!user){
              return res.status(404).json({ msg: 'Books not found', data: null });
          
            }
            return res.status(200).json({
              err: null,
              msg: 'Books retrieved successfully',
              data: user[0].borrowedBooks
            });
      };