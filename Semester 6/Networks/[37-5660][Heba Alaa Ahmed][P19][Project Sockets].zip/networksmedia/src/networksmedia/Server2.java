package networksmedia;

import java.io.*;
import java.util.*;
import java.net.*;

public class Server2
{
 static Vector<TheClientHandler> clients = new Vector<>();
 static int noOfClients = 0;

public static void GetMemberList(){
 Vector<TheClientHandler> clientslist = Server2.clients;
 System.out.print("Members in this chat are: ");
 
 for(int i=0; i< clientslist.size();i++){
	System.out.print(clientslist.get(i).name);
 }
}
 
 
 public static void main(String[] args) throws IOException 
 {
     Socket serversocket2 = new Socket(InetAddress.getByName("Heba"),3000);
	
     DataInputStream dinputs1 = new DataInputStream(serversocket2.getInputStream());
     
     Thread sendMessage1 = new Thread(new Runnable() 
     {
         @Override
         public void run() {
        	 while(true){
                 String receivedmessage1;
     			try {
     				receivedmessage1 = dinputs1.readUTF();
     	             
     	             System.out.println(receivedmessage1);
     	             StringTokenizer st = new StringTokenizer(receivedmessage1, "#"); //breaking the message
     	             String MsgToSend = st.nextToken();
     	             String recipient = st.nextToken();
     	             String ssd= st.nextToken();
     	            
     	      
     	            
     	             if(MsgToSend.equals("getmemberslist")){
     	            	 GetMemberList();
     	             }
     	             
     	             
     	            for (TheClientHandler mc : Server2.clients) 
     	             {
     	            	System.out.println("ay aafdfdf");
     	            	System.out.println(recipient);
     	                 if (mc.name.equals(recipient)) 
     	                 {
     	                	 System.out.println("asdjdd");
     	                     mc.doutputs.writeUTF(ssd+" : "+MsgToSend);
     	                    
     	                     break;
     	                 }
     	                
     	             
     	             }
     				
     				
     				
     				
     			} catch (IOException e) {
     				// TODO Auto-generated catch block
     				e.printStackTrace();
     			}
        	 }
                 //  String msg = scn.nextLine();                   
         }
     });
     
     sendMessage1.start();
     
     ServerSocket serversocket = new ServerSocket(4000); 
     
     Socket s;
    while (true) 
     {
         s = serversocket.accept();
         System.out.println("New client request received : " + s);
          
         DataInputStream dinputs = new DataInputStream(s.getInputStream());
         DataOutputStream doutputs = new DataOutputStream(s.getOutputStream());
          
         System.out.println("Creating a new handler for this client...");

         TheClientHandler mtch = new TheClientHandler(s,serversocket2,"client s2" + noOfClients, dinputs, doutputs);

         Thread t = new Thread(mtch);
          
         System.out.println("Adding this client to active client list");

         clients.add(mtch);
         t.start();
         noOfClients++;
     }
 }
}
