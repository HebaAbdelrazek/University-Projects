package networksmedia;

import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.net.*;

import javax.imageio.ImageIO;

public class Server 
{

	static Vector<TheClientHandler> clients = new Vector<>();
	static int noOfClients = 0;
	static ArrayList<String> requests = new ArrayList<>();
	
	//static ArrayList<String> request = new ArrayList<>();
	public static void main(String[] args) throws IOException 
	{
		ServerSocket serversocket = new ServerSocket(1233); 
		Socket s;
		while (true) 
		{
			s = serversocket.accept();
			System.out.println("New client request received : " + s);

			DataInputStream dinputs = new DataInputStream(s.getInputStream());
			DataOutputStream doutputs = new DataOutputStream(s.getOutputStream());

			System.out.println("Creating a new handler for this client...");

			TheClientHandler mtch = new TheClientHandler(s,"client " + noOfClients, dinputs, doutputs);

			Thread t = new Thread(mtch);

			System.out.println("Adding this client to active client list");

			clients.add(mtch);
			t.start();
			noOfClients++;
		}
	}

	public static void recieveRequest(String method, String message){
		String req= method+" "+message+" HTTP 1.1 "+"\n"+"Heba "+"\n"+"JPEG/TXT/PNG/MP4 "+"\n"+"Connection:keep-alive ";
		requests.add(req);
		System.out.println(requests);
		//System.out.println("This request is: "+ req);
	}

	public static byte[] respondRequest(int index,String response) throws IOException{
		String req=Server.requests.get(index);
		StringTokenizer st = new StringTokenizer(req, " "); //breaking the message
		String method = st.nextToken();
		String message = st.nextToken();
		String remaining = st.nextToken();
		String status="";
		byte[] byteArray = null;
		//String response="";
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		String timestamp  = dateFormat.format(new Date());

		StringTokenizer st2 = new StringTokenizer(message,"."); 
		String path = st2.nextToken(); 
		String type = st2.nextToken(); //format of the object
		if(!(type.equals("png") || type.equals("jpeg") || type.equals("txt") || type.equals("mp4")))
		{
			status="404 Not Found";
			//return "File is not in the right format";
			response = "File is not in the right format";
			return null;
		}
		else{
			status="200 OK";
		}
		
		
		if(method.equals("GET")){
			
			
			switch(type){
			case "png": 
				BufferedImage inputImage1 = ImageIO.read(new File(path+"."+type));
				ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
				ImageIO.write( inputImage1, "png", baos1 );
				baos1.flush();
				byteArray = baos1.toByteArray();
				baos1.close();
				
				break;
			
			case "jpeg":
				BufferedImage inputImage2 = ImageIO.read(new File(path+"."+type));
				ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
				ImageIO.write( inputImage2, "jpeg", baos2 );
				baos2.flush();
				byteArray = baos2.toByteArray();
				baos2.close();
				break;
			
			case "txt": 		
				FileReader fr = new FileReader(path+"."+type); 
				BufferedReader textReader = new BufferedReader(fr); 

				break;
		
			case "mp4":
				   
				break;
			default:break;
			}
			
			
		}
//		else if(method.equals("POST")){
//
//			switch(type){
//			case "png": 
//				
//				break;
//			case "jpeg":
//				
//				
//				break;
//			case "txt": 		
//
//				break;
//			case "mp4":
//				   
//				break;
//			default:break;
//			}
//			
//			
//
//
//		}
//		else return "Method not valid";
		else {
			response = "Method not valid"; return null;
		}
		response = status+" HTTP 1.1"+"\n"+timestamp+"\n"+type+"\n"+"Connection:keep-alive";
		return byteArray;
	}
	

}