var mongoose = require('mongoose'),
moment = require('moment'),
Validations = require('../utils/Validations');
const Notification = mongoose.model('Notification');
//passport = require('passport');
//notifications = mongoose.model('Notification'),
//nodemailer = require('nodemailer');

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

module.exports.createNotification = function (req, res, next){
  
    console.log("e3ml el notification naw");

    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("acmlproject");
        var notification = req.body;
        console.log("hiiiii");
        dbo.collection("notifications").insertOne(notification, function(err, res) {
          if (err) 
            console.log("This notification already exists");
          else
            console.log("Notification created successfulyy");
          db.close();
        });
      });
  };

  module.exports.getNotifications = async (req, res) => {
    console.log("notifications yasta argouk");
    
    const notifications = await Notification.find({receiver:'all_users'}).exec();
    console.log(notifications);

      if(!notifications){
          return res.status(404).json({ msg: 'Notifications not found', data: null });
      
        }
        return res.status(200).json({
          err: null,
          msg: 'Notifications retrieved successfully',
          data: notifications
        });
  };


  module.exports.getNotificationsBorrowedBooks = async (req, res) => {
    console.log("notifications yasta argouk");
    
    const notifications = await Notification.find({receiver:req.params.username}).exec();
    console.log(notifications);
    
      if(!notifications){
          return res.status(404).json({ msg: 'Notifications not found', data: null });
      
        }
        return res.status(200).json({
          err: null,
          msg: 'Notifications retrieved successfully',
          data: notifications
        });
  };



