import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

public class EndGame implements Problem{
	public Node initialState;

	String grid;
	
	public int rows;
	public int columns;
	
//	public int damage;
//	public int stonesCollected;
	
	public int[][] warriorsArray;
	public int[][] stonesArray; //array list that carries each stone's x and y coordinates
	
	public int[] thanosArray; //array list that carries thanos's id and x and y coordinates
	public int[] ironManArray; //current cell
	
	public EndGame(String grid) {
		this.grid = grid;
		//INITIALIZE GRID
		String[] gridTemp = grid.split(";");
		
		String[] rowsAndColumns = gridTemp[0].split(",");
		this.rows = Integer.parseInt(rowsAndColumns[0]);
		this.columns = Integer.parseInt(rowsAndColumns[1]);
		
		//adding iron man to the grid
		String[] ironMan = gridTemp[1].split(",");
				
		ironManArray = new int[2];
		ironManArray[0] = Integer.parseInt(ironMan[0]); //add iron man x coordinate
		ironManArray[1] = Integer.parseInt(ironMan[1]); //add iron man y coordinate
		
		//adding thanos to the grid
		String[] thanos = gridTemp[2].split(",");
		
		thanosArray = new int[2];
		thanosArray[0] = Integer.parseInt(thanos[0]); //add thanos x coordinate
		thanosArray[1] = Integer.parseInt(thanos[1]); //add thanos y coordinate
		
		//adding the stones to the grid
		String[] stones = gridTemp[3].split(",");
		
		stonesArray = new int[6][2];
		
		int countStones = 0;
		for(int i = 0 ; i < stones.length-1 ; i+=2) {
			stonesArray[countStones][0] = Integer.parseInt(stones[i]);
			stonesArray[countStones][1] = Integer.parseInt(stones[i+1]);
			countStones++;
		}	
		
		//adding the warriors to the grid
		String[] warriors = gridTemp[4].split(",");
		
		warriorsArray = new int[warriors.length/2][2];
		
		int countWarriors = 0;
		for(int i = 0 ; i < warriors.length-1 ; i+=2) {
			warriorsArray[countWarriors][0] = Integer.parseInt(warriors[i]);
			warriorsArray[countWarriors][1] = Integer.parseInt(warriors[i+1]);
			countWarriors++;
		}	
		
//		this.stonesCollected = 0;
//		this.damage = 0;

	}
	
	public void setInitialState(Node initialState) {
		this.initialState = initialState;
	}
	
	public Node getInitialState() {
		return initialState;
	}

	@Override
	public boolean isGoal(Node node) {
		if(!node.isRootNode())
			return node.getOperator().equals("snap");
		return false;
	}

	@Override
	public ArrayList<String> getOperations(State state) {
		ArrayList<String> operations = new ArrayList<String>();
		
		boolean warriorFound = false;
		boolean snap = false;
		
		int[] currPosition = new int[2];
		currPosition[0] = state.currPosition[0];
		currPosition[1] = state.currPosition[1];
		
		if(currPosition[0] > 0) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0]-1;
			newPosition[1] = currPosition[1];
			
			if(state.contains(state.warriors, newPosition))
				operations.add("kill");
		}
		else if(currPosition[0] < rows-1) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0]+1;
			newPosition[1] = currPosition[1];
			
			if(state.contains(state.warriors, newPosition))
				operations.add("kill");
		}
		else if(currPosition[1] > 0) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0];
			newPosition[1] = currPosition[1]-1;
			
			if(state.contains(state.warriors, newPosition))
				operations.add("kill");
		}
		else if(currPosition[1] < columns-1) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0];
			newPosition[1] = currPosition[1]+1;
			
			if(state.contains(state.warriors, newPosition))
				operations.add("kill");
		}
		
		//moving not into thanos's cell
		if(currPosition[0] > 0 && !(this.thanosArray[0] == currPosition[0]-1 && this.thanosArray[1] == currPosition[1])) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0]-1;
			newPosition[1] = currPosition[1];
			
			if(!(state.contains(state.warriors, newPosition)))
				operations.add("up");
		}
		
		if(currPosition[0] < rows-1 && !(this.thanosArray[0] == currPosition[0]+1 && this.thanosArray[1] == currPosition[1])) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0]+1;
			newPosition[1] = currPosition[1];
			
			if(!(state.contains(state.warriors, newPosition)))
				operations.add("down");
		}
		
		if(currPosition[1] > 0 && !(this.thanosArray[0] == currPosition[0] && this.thanosArray[1] == currPosition[1]-1)) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0];
			newPosition[1] = currPosition[1]-1;
			
			if(!(state.contains(state.warriors, newPosition)))
				operations.add("left");
		}
		
		if(currPosition[1] < columns-1 && !(this.thanosArray[0] == currPosition[0] && this.thanosArray[1] == currPosition[1]+1)) {
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0];
			newPosition[1] = currPosition[1]+1;
			
			if(!(state.contains(state.warriors, newPosition)))
				operations.add("right");
		}
		
		//moving into thanos's cell
		if(currPosition[0] > 0 && this.thanosArray[0] == currPosition[0]-1 && this.thanosArray[1] == currPosition[1] && state.damage < 100 && state.stonesCollected == 6) 
			operations.add("up");
		
		else if(currPosition[0] < rows-1 && this.thanosArray[0] == currPosition[0]+1 && this.thanosArray[1] == currPosition[1] && state.damage < 100 && state.stonesCollected == 6) 
			operations.add("down");
		
		else if(currPosition[1] > 0 && this.thanosArray[0] == currPosition[0] && this.thanosArray[1] == currPosition[1]-1 && state.damage < 100 && state.stonesCollected == 6) 
			operations.add("left");
		
		else if(currPosition[1] < columns-1 && this.thanosArray[0] == currPosition[0] && this.thanosArray[1] == currPosition[1]+1 && state.damage < 100 && state.stonesCollected == 6) 
			operations.add("right");
		
		//iron man can collect a stone only if he is in the same cell as the stone
		if(state.contains(state.stones, currPosition)) {
			operations.add("collect");
		}
		
		if(currPosition[0] == this.thanosArray[0] && currPosition[1] == this.thanosArray[1]) {
			operations.add("snap"); 
		}
		
		
	
		
		return operations;
	}

	@Override
	public State getNextState(State state, String action) {
		
		State nextState = null;
		
		int[] currPosition = new int[2];
		currPosition[0] = state.currPosition[0];
		currPosition[1] = state.currPosition[1];
		
		if(action.equals("left")) { 
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0];
			newPosition[1] = currPosition[1]-1;
			
			nextState = new State(state.warriors, state.stones, newPosition);
		}
		else if(action.equals("right")) { 
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0];
			newPosition[1] = currPosition[1]+1;
			
			nextState = new State(state.warriors, state.stones, newPosition);
		}
		else if(action.equals("up")) { 
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0]-1;
			newPosition[1] = currPosition[1];
			
			nextState = new State(state.warriors, state.stones, newPosition);
		}
		else if(action.equals("down")) { 
			int[] newPosition = new int[2];
			newPosition[0] = currPosition[0]+1;
			newPosition[1] = currPosition[1];
			
			nextState = new State(state.warriors, state.stones, newPosition);
		}
		else if(action.equals("kill")) { 
			
			int[][] newWarriors = new int[state.warriors.length][2];
			
			for(int i = 0 ; i < state.warriors.length ; i++) {
				newWarriors[i][0] = state.warriors[i][0];
				newWarriors[i][1] = state.warriors[i][1];
			}
			
			ArrayList<ArrayList<Integer>> adjacentCells = new ArrayList<ArrayList<Integer>>();
			
			
			if(currPosition[0] > 0) {
				ArrayList<Integer> tmp = new ArrayList<>();
				tmp.add(currPosition[0]-1);
				tmp.add(currPosition[1]);
				
				adjacentCells.add(tmp);
			}
			if(currPosition[0] < rows-1) {
				ArrayList<Integer> tmp = new ArrayList<>();
				tmp.add(currPosition[0]+1);
				tmp.add(currPosition[1]);
				
				adjacentCells.add(tmp);
			}
			if(currPosition[1] > 0) {
				ArrayList<Integer> tmp = new ArrayList<>();
				tmp.add(currPosition[0]);
				tmp.add(currPosition[1]-1);
				
				adjacentCells.add(tmp);
			}
			if(currPosition[1] < columns-1) {
				ArrayList<Integer> tmp = new ArrayList<>();
				tmp.add(currPosition[0]);
				tmp.add(currPosition[1]+1);
				
				adjacentCells.add(tmp);
			}
			
			for(int i = 0 ; i < adjacentCells.size() ; i++) {
				int[] tmp = new int[2];
				tmp[0] = adjacentCells.get(i).get(0);
				tmp[1] = adjacentCells.get(i).get(1);
				
				if(state.contains(state.warriors, tmp)) {
					for(int j = 0 ; j < state.warriors.length ; j++) {
						if(state.warriors[j][0] == tmp[0] && state.warriors[j][1] == tmp[1]) {
							newWarriors[j][0] = -1;
							newWarriors[j][1] = -1;
						}
					}
				}
			}
			
			nextState = new State(newWarriors, state.stones, currPosition);
		}
		else if(action.equals("collect")) { 
			int[][] newStones = new int[6][2];
			
			for(int i = 0 ; i < state.stones.length ; i++) {
				newStones[i][0] = state.stones[i][0];
				newStones[i][1] = state.stones[i][1];
			}
			
			for(int i = 0 ; i < state.stones.length ; i++) {
				if(state.stones[i][0] == currPosition[0] && state.stones[i][1] == currPosition[1]) {
					newStones[i][0] = -1;
					newStones[i][1] = -1;
				}
			}
			
			nextState = new State(state.warriors, newStones, currPosition);
		}
		else if(action.equals("snap")) {
			return state;
		}
		return nextState;
	}

	@Override
	public int getStepCost(String action, State nextState) {
		int cost = 0;
		
		int[] nextPos = new int[2];
		nextPos[0] = nextState.currPosition[0];
		nextPos[1] = nextState.currPosition[1];
		
		ArrayList<ArrayList<Integer>> adjacentCells = new ArrayList<ArrayList<Integer>>();
		
		
		if(nextPos[0] > 0) {
			ArrayList<Integer> tmp = new ArrayList<>();
			tmp.add(nextPos[0]-1);
			tmp.add(nextPos[1]);
			
			adjacentCells.add(tmp);
		}
		if(nextPos[0] < rows-1) {
			ArrayList<Integer> tmp = new ArrayList<>();
			tmp.add(nextPos[0]+1);
			tmp.add(nextPos[1]);
			
			adjacentCells.add(tmp);
		}
		if(nextPos[1] > 0) {
			ArrayList<Integer> tmp = new ArrayList<>();
			tmp.add(nextPos[0]);
			tmp.add(nextPos[1]-1);
			
			adjacentCells.add(tmp);
		}
		if(nextPos[1] < columns-1) {
			ArrayList<Integer> tmp = new ArrayList<>();
			tmp.add(nextPos[0]);
			tmp.add(nextPos[1]+1);
			
			adjacentCells.add(tmp);
		}
		
		
		if(action.equals("left") || action.equals("right") || action.equals("up") || action.equals("down")) { //actions that involve moving to another cell
			for(int i = 0 ; i < adjacentCells.size() ; i++) {
				int[] tmp = new int[2];
				tmp[0] = adjacentCells.get(i).get(0);
				tmp[1] = adjacentCells.get(i).get(1);
				
				if(nextState.contains(nextState.warriors, tmp)) {
					for(int j = 0 ; j < nextState.warriors.length ; j++) {
						if(nextState.warriors[j][0] == tmp[0] && nextState.warriors[j][1] == tmp[1]) {
							cost+=1;
						}
					}
				}
				else if(tmp[0] == thanosArray[0] && tmp[1] == thanosArray[1])
					cost+=5;
			}
		}
		else { 
			
			if(action.equals("kill")) {
				for(int i = 0 ; i < adjacentCells.size() ; i++) {
					int[] tmp = new int[2];
					tmp[0] = adjacentCells.get(i).get(0);
					tmp[1] = adjacentCells.get(i).get(1);
					
					if(nextState.contains(nextState.warriors, tmp)) {
						for(int j = 0 ; j < nextState.warriors.length ; j++) {
							if(nextState.warriors[j][0] == tmp[0] && nextState.warriors[j][1] == tmp[1]) {
								cost+=2;
							}
						}
					}
					else if(tmp[0] == thanosArray[0] && tmp[1] == thanosArray[1])
						cost+=5;
				}
			}
			else if(action.equals("collect")){
				cost+=3;
				
				for(int i = 0 ; i < adjacentCells.size() ; i++) {
					int[] tmp = new int[2];
					tmp[0] = adjacentCells.get(i).get(0);
					tmp[1] = adjacentCells.get(i).get(1);
					
					if(nextState.contains(nextState.warriors, tmp)) {
						for(int j = 0 ; j < nextState.warriors.length ; j++) {
							if(nextState.warriors[j][0] == tmp[0] && nextState.warriors[j][1] == tmp[1]) {
								cost+=1;
							}
						}
					}
					else if(tmp[0] == thanosArray[0] && tmp[1] == thanosArray[1])
						cost+=5;
				}
			}
		}
		
		return cost;
	}
	
	public boolean nodeVisited(Node prevNode, Node currNode) { //handles repeated states
			
		boolean move = false;
		
		if(prevNode.getState().currPosition[0] == currNode.getState().currPosition[0]
				&& prevNode.getState().currPosition[1] == currNode.getState().currPosition[1]){
			if(prevNode.getState().warriorsEquals(currNode.getState())
					&& prevNode.getState().stonesEquals(currNode.getState()))
				return true;
				
		}
		
		return false;
	}
	
	public void visualize(String solution) {
		
		
	}

	
}
