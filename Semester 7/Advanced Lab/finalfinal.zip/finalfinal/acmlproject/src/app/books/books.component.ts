import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  ourBooks: any[];
  numberOfCopies = [3,3,3,3,3,3,3,3,3,3];
  index: number;
  constructor(private bookService: BookService){}

  ngOnInit() {
    
      this.bookService.displayBooks()
      .subscribe(
        (data) => {
          this.ourBooks = data.data;
          console.log(this.ourBooks);
        }
        ,
        (error) => console.log(error)
        );
        
  }

  adminGetBooks(){
    console.log("hoi");
    this.bookService.getBooks()
    .subscribe(
      (data) => {
        //this.ourBooks = data.books;
        //console.log(this.ourBooks[0]);
        data.books.forEach(book => {
          this.bookService.registerBook(book.title, book.image, book.subtitle, book.isbn13, 3);
          //console.log(book.title);

        });
      }
      ,
      (error) => console.log(error)
      );
  }

  

  onBorrow(event1: String, event2: String, event3: String, event4: String, event5: number){
      
    if(event5>0){
      var update={
          copies: (event5-1)
      };
        
        this.bookService.updateCopies(update, event4)
        .subscribe((res:any)=>{ 
          this.bookService.displayBooks()
          .subscribe(
            (data) => {
              this.ourBooks = data.data;
            }
            ,
            (error) => console.log(error)
            );
        });


        var update2 = {
          title: event1,
          cover: event2,
          subtitle: event3,
          isbn: event4
        };

        this.bookService.addBorrowedBooks(update2);


      }
      else{
        alert("Sorry! No more copies for your shelf :(")
      }
      }
  

}
