package networksmedia;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.Vector;

public class Client 
{
 final static int ServerPort = 1233;
 
 public static void main(String args[]) throws UnknownHostException, IOException 
 {
     Scanner scn = new Scanner(System.in);
     InetAddress ip = InetAddress.getByName("Heba");
     Socket s = new Socket(ip, ServerPort);
      
     DataInputStream dinputs = new DataInputStream(s.getInputStream());
     DataOutputStream doutputs = new DataOutputStream(s.getOutputStream());

     Thread sendMessage = new Thread(new Runnable() 
     {
         @Override
         public void run() {
             while (true) {
                 String msg = scn.nextLine();
                  
                 try {
                     doutputs.writeUTF(msg);
                 } catch (IOException e) {
                     e.printStackTrace();
                 }
             }
         }
     });
     Thread readMessage = new Thread(new Runnable() 
     {
         @Override
         public void run() {

             while (true) {
                 try {
                     String msg = dinputs.readUTF();
                     System.out.println(msg);
                 } catch (IOException e) {
                     e.printStackTrace();
                 }
             }
         }
     });
     sendMessage.start();
     readMessage.start();
     
    
     
 }
}