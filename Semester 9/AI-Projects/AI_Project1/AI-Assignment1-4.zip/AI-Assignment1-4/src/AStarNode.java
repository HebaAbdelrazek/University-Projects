
public class AStarNode extends Node{

	public AStarNode(State state) {
		super(state);
	}
	
	public AStarNode(State state, Node parent, String operator, int stepCost) {
		super(state, parent, operator, stepCost);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int compareTo(Object o) {
		return this.hCost+this.pathCost >= (((Node)o).hCost+((Node)o).pathCost) ? 1:-1;
	}

}
