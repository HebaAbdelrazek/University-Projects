var mongoose = require('mongoose');

var notificationSchema = mongoose.Schema({
  time: {
    type: Date,
    default: Date.now
  },
  message: {
    type: String
  },
  receiver:{
    type: String
  }
});

module.exports = mongoose.model('Notification', notificationSchema);